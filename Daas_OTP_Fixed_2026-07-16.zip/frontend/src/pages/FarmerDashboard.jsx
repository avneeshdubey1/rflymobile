import { useAuth } from '../context/useAuth';

export default function FarmerDashboard() {
  const { user, logout } = useAuth();

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome, {user?.name || 'Farmer'}!</h1>
      <p>Village: {user?.village || 'N/A'} | District: {user?.district || 'N/A'}</p>
      
      <div style={{ marginTop: '2rem' }}>
        <h2>Your Services</h2>
        <p>You currently have no active drone requests.</p>
        <button disabled>Request a Drone (Coming Soon)</button>
      </div>

      <div style={{ marginTop: '2rem' }}>
        <button onClick={logout}>Logout</button>
      </div>
    </div>
  );
}
