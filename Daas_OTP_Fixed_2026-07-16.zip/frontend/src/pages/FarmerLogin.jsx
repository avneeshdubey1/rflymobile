import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { signInWithPhoneNumber } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { clearPhoneRecaptcha, getPhoneRecaptcha, normalizeIndianPhone } from '../lib/firebasePhone';
import { API_URL } from '../config';
import { useAuth } from '../context/useAuth';

export default function FarmerLogin() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [confirmation, setConfirmation] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => () => clearPhoneRecaptcha(), []);

  const sendOtp = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const result = await signInWithPhoneNumber(auth, normalizeIndianPhone(phone), getPhoneRecaptcha());
      setConfirmation(result);
    } catch (failure) {
      clearPhoneRecaptcha();
      setError(failure?.message || 'Unable to send OTP.');
    } finally {
      setBusy(false);
    }
  };

  const verifyOtp = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const credential = await confirmation.confirm(otp.trim());
      const idToken = await credential.user.getIdToken();
      const response = await fetch(`${API_URL}/api/auth/farmer/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Login failed.');
      login(data.user, data.token);
      navigate('/farmer/dashboard', { replace: true });
    } catch (failure) {
      setError(failure?.message || 'OTP verification failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="panel form-container auth-card">
        <p className="eyebrow eyebrow--accent">FARMER LOGIN</p>
        <h1>Welcome back</h1>
        <p>Use the mobile number registered with your Farmer account.</p>
        {error && <div className="alert error" role="alert">{error}</div>}
        {!confirmation ? (
          <form className="lead-form" onSubmit={sendOtp}>
            <div className="input-group">
              <label htmlFor="login-phone">Mobile number</label>
              <input id="login-phone" inputMode="numeric" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="9876543210" maxLength="14" required disabled={busy} />
            </div>
            <div id="recaptcha-container" />
            <button className="submit-btn" disabled={busy}>{busy ? 'Sending…' : 'Send OTP'}</button>
          </form>
        ) : (
          <form className="lead-form" onSubmit={verifyOtp}>
            <div className="input-group">
              <label htmlFor="login-otp">6-digit OTP</label>
              <input id="login-otp" inputMode="numeric" autoComplete="one-time-code" value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, '').slice(0, 6))} minLength="6" maxLength="6" required disabled={busy} />
            </div>
            <button className="submit-btn" disabled={busy || otp.length !== 6}>{busy ? 'Verifying…' : 'Login'}</button>
            <button type="button" className="login-btn" onClick={() => { setConfirmation(null); setOtp(''); clearPhoneRecaptcha(); }} disabled={busy}>Use another number</button>
          </form>
        )}
        <p>New Farmer? <Link to="/">Create an account</Link></p>
        <p>Employee? <Link to="/login">Employee login</Link></p>
      </section>
    </main>
  );
}

