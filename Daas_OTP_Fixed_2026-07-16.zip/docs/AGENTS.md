# AGENTS.md — Instructions for AI Coding Agents Working in This Repo

This file tells you (the coding agent) how to work in the customer-neutral DaaS codebase. Read this before writing code. For *what* to build, see `SPEC.md`. For *why* the domain works this way, see `CONTEXT.md`. Do not introduce customer-specific branding unless the user explicitly approves it. If something here conflicts with a person's instruction mid-task, the person's explicit instruction wins — but flag the conflict rather than silently picking one.

---

## 1. Build Order Is Not a Suggestion

`SPEC.md` §18 defines 14 phases in a specific order. **Do not implement a later phase before an earlier one is done and passing its acceptance criteria.** Phase 3 (auto-assignment) assumes Phase 1 (data layer) and Phase 2 (intake/geofencing) already work. If you're asked to jump ahead, say so before proceeding — later phases have implicit dependencies on earlier ones that aren't always spelled out twice.

If a task doesn't obviously map to a phase number, check `SPEC.md`'s table of contents before guessing where it belongs.

---

## 2. Non-Negotiable Architectural Rules

These are load-bearing for the whole system. Violating them isn't a style issue — it breaks the promises made elsewhere in the spec.

1. **Repository Pattern is mandatory.** Controllers, routes, and sockets never import `PrismaClient` directly. All database access goes through `backend/src/repositories/`. This is what makes the data layer swappable later without touching business logic — don't shortcut it "just this once."
2. **Every state-changing action writes to `AuditLog`**, via `auditLogService`, not ad hoc. The Logbook/CRM timeline view (`SPEC.md` §12) is built entirely from this table. If you add a new mutation and skip the audit write, you've created a silent gap in that timeline.
3. **Never hardcode a rate, threshold, or compliance value.** Anything in `SPEC.md` §9 or §11 (out-of-range rate, discrepancy threshold, weather thresholds, DGCA validity windows) reads from `PricingConfig` or an equivalent config table — never a literal in code. These are placeholder values owned by non-dev stakeholders; hardcoding them defeats the entire point of making them editable.
4. **Automated systems fail open to a human queue, never silently.** The auto-assignment engine, weather gate, and notification cascade all have an explicit fallback status (`NEEDS_MANUAL_SCHEDULING`, `weatherSuitable = null` + warning, etc.). If you're implementing a new automated step, ask: "what happens when this fails or finds no candidates?" and make that path land somewhere a human will see it — never a dead end.
5. **No feature blocks on an unimplemented integration.** Mission completion never blocks on payment (`SPEC.md` §13). The pipeline never blocks on the weather API being down (§7). If you're integrating something external (WhatsApp, UPI gateway, weather API), build the fallback path *first*, then the happy path.
6. **i18n from day one on any farmer-facing or newly-touched UI string.** No hardcoded English strings in components you touch — route through the i18n library/service, even if only `en.json`/`ta.json` exist right now (`SPEC.md` §10).
7. **State machine transitions are server-enforced, not just UI-hidden.** If the UI hides a button, the backend must still reject the equivalent API call from a disallowed role or out-of-order state. Assume someone will call the API directly.

---

## 3. Local Dev Setup

```bash
# One-time: start Postgres
docker run --name rfly-postgres -e POSTGRES_PASSWORD=devpass -e POSTGRES_DB=rfly_daas -p 5432:5432 -d postgres:16

# Backend
cd backend
cp .env.example .env        # fill in DATABASE_URL, FORM_WEBHOOK_SECRET, etc.
npm install
npx prisma migrate dev
DEMO_USER_PASSWORD=<enter locally> node prisma/seed.js
npm run dev

# Frontend
cd frontend
npm install
npm run dev
```

Required env vars (backend `.env`) — see `.env.example` for the full list, keep it current as new integrations land:
```
DATABASE_URL=
JWT_SECRET=
DEMO_USER_PASSWORD=          # required only during development seed; enter locally, never commit
FORM_WEBHOOK_SECRET=
WHATSAPP_API_KEY=          # placeholder in dev, mock the client if unset
WEATHER_API_KEY=           # placeholder in dev, mock the client if unset
UPI_GATEWAY_KEY=           # placeholder in dev, mock the client if unset
UPI_WEBHOOK_SECRET=        # required before enabling a real gateway webhook
NOTIFICATION_CASCADE_TIMERS_MS=   # override for dev/testing, e.g. shortened intervals
CHAT_AUTO_CLOSE_AFTER_MS=         # optional dev/test override; production default is 24 hours after all messages are read
CHAT_AUTO_CLOSE_INTERVAL_MS=      # optional job polling interval; defaults to 60 seconds
```

**Rule:** if an integration's API key is unset in dev, the corresponding service should mock/no-op rather than crash — consistent with "fail open" in §2.5 above.

---

## 4. Repo Structure Map

```
backend/
  prisma/            schema.prisma, seed.js — see SPEC.md §2
  src/
    repositories/     ALL Prisma access — see rule §2.1
    controllers/       thin, call repositories/services only
    routes/
    services/          business logic — see SPEC.md §3 for the full list
    sockets/            chatSocket.js, locationSocket.js
    jobs/                cron-style background tasks (notification escalation, chat auto-close)
    integrations/        external API clients (Google Form webhook, WhatsApp, UPI, weather)
    middleware/
    app.js
frontend/
  src/
    pages/              one per role dashboard, see SPEC.md §16
    context/             AuthContext.jsx
    locales/              en.json, ta.json — see rule §2.6
    components/
    App.jsx
SPEC.md               source of truth for what to build
AGENTS.md             this file
CONTEXT.md            business/domain background
```

---

## 5. Coding Conventions

- **JS/Node style:** match whatever ESLint/Prettier config exists in the repo at the time; if none exists yet, default to standard modern ES modules, 2-space indent, semicolons on.
- **Naming:** Prisma models are PascalCase singular (`Lead`, `Assignment`); API routes are kebab/plural (`/api/leads`, `/api/assignments`); repository functions are camelCase verbs (`findAll`, `updateStatus`, `create`).
- **Error handling:** every route handler wraps in try/catch and returns a consistent error shape (`{ error: string, code?: string }`); never let an unhandled rejection crash the process.
- **Secrets:** never commit `.env`; never log full request bodies that might contain phone numbers or payment details — log IDs, not PII.
- **Comments:** where a value is a known placeholder (§2.3), comment it as such inline, e.g. `// PLACEHOLDER — real rate owned by marketing, see SPEC.md §11`, so it's grep-able later.

---

## 6. Testing Expectations

- Never declare the frontend working from lint/build alone. Run `npm run test:browser` from `frontend/` and confirm that the application renders and the affected workflows pass in a real browser. Record and resolve failures; the harness uses only the disposable `rfly_daas_browser_test` database.

- Each phase's acceptance criteria in `SPEC.md` §18 is the minimum bar — write tests (or at least a manual verification script) that demonstrably satisfy them before considering a phase done.
- State machine guards (§2.7 above) need explicit tests for the *rejected* paths, not just the happy path — e.g. "pilot cannot start a mission they haven't accepted" should be a test, not just an assumption.
- For anything involving timers (notification cascade, chat auto-close), don't hardcode wait times in tests — use the env-var override mentioned in §3 to shrink intervals.

---

## 7. What NOT to Do

- Don't invent scope not in `SPEC.md`. If something seems missing or ambiguous, flag it in your output rather than guessing and building it silently.
- Don't reach for a different DB, ORM, calendar library, or real-time layer than what's specified — those were deliberated decisions (see `CONTEXT.md` for the reasoning), not defaults to swap out for convenience.
- Don't hardcode business values (§2.3) — this is worth repeating because it's the single most common shortcut that quietly breaks the "config-driven" promise of this system.
- Don't build a robo-call system for the notification cascade's "call" step — it's explicitly a human dispatch task (`SPEC.md` §6.2, §19).
- Don't skip the audit log write "for now" — retrofitting it later means reconstructing history that was never captured.
- Don't add a new npm package for something a currently-installed one already covers — check `package.json` first.

---

## 8. Legacy Codebase — Reference Only, Never a Starting Point

This is a fresh build, not an in-place refactor. The pre-existing monolith (JSON file storage, vanilla CSS, manual-only assignment) is kept available at `rfly-legacy-reference/` (read-only) for one purpose only: **answering "how did we handle X before"** when `SPEC.md` and `CONTEXT.md` don't say — e.g. the exact fields the old Google Form mapping expected, how the old login flow worked, an edge case someone already solved once.

Rules:
- Never import from, copy-paste from, or directly adapt a file from `rfly-legacy-reference/` into the new codebase. Treat it the same as you'd treat search results — read for understanding, then write the real thing fresh, in the new architecture.
- If old and new behavior genuinely conflict (e.g. the old app let Sales assign pilots — `SPEC.md` explicitly forbids this now), the new spec always wins. The old code shows you *a* prior decision, not *the* correct one — most of why this rebuild exists is that several of those prior decisions were wrong (see `current_codebase_overview.md`'s "Identified Architectural Flaws" if you need the original reasoning).
- Almost every layer changes in this rebuild (data layer, styling, assignment logic, real-time, integrations) — so don't go looking for things to "port over" by default. Assume fresh unless the old code answers a specific question you have.

## 9. When You're Unsure

Prefer asking (or clearly flagging an assumption and proceeding) over silently guessing, especially for:
- Anything touching money (`PricingConfig`, `PaymentRecord`) — get the placeholder-vs-real distinction right.
- Anything touching the state machine (`SPEC.md` §4) — an incorrect transition guard is a production bug waiting to happen, not a cosmetic issue.
- Anything where `SPEC.md` §20 lists an open item — those are explicitly unresolved and waiting on non-dev input; don't resolve them yourself with a guess presented as fact.

## 10. Milestone Closeout

After completing a major phase, update `history_of_changes.md` with the date, scope, verification performed, and known follow-up work. In the handoff, include a short plain-language explanation of what now works and what comes next; do not assume the reader already knows the implementation technology.

Before production, deployment, security, privacy, or live-integration work, read the root `production hardening.md` completely. Treat its recorded product decisions as mandatory, update its status/checklists when work changes them, and never mark an item complete without verification evidence.

## 11. Placeholder and Integration Register

`current placeholders.md` at the repository root is the living handoff register for temporary values, mocks, and integrations that still require external input. Whenever a change adds, changes, or resolves one of these items, update that document in the same change with the active file/line reference, safe current behaviour, and the required owner/input. Never place a secret in the register.
