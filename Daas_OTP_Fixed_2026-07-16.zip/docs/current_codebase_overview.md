# RFLY DaaS - Current Codebase Overview

This document provides a detailed breakdown of the current RFLY Drone as a Service (DaaS) codebase. It is intended to help reviewers understand the existing architecture, the flow of data, and the role of each component before the upcoming refactoring phase.

## High-Level Architecture
The current application is a monolithic web application structured into a clear frontend and backend:
*   **Frontend:** React (bootstrapped with Vite), using React Router for navigation, and styled with Vanilla CSS (Glassmorphism aesthetics).
*   **Backend:** Node.js with Express.
*   **Database:** A mocked database using static JSON files. It does not currently use a relational or NoSQL database engine.

---

## Backend Components (`/backend`)

The backend follows an MVC-like structure (without the views) and acts as a RESTful API provider for the frontend.

### 1. Controllers (`/backend/controllers`)
These files contain the core business logic for the application.
*   **`leadController.js`**: Handles incoming service requests from farmers. It creates `pending` leads and contains the logic for Sales Reps to process them (which currently involves mapping data and dispatching a POST request to a Google Form).
*   **`assignmentController.js`**: Manages the lifecycle of a spraying mission. It handles the manual assignment of a Pilot and a Drone to a Lead, updates statuses (`in_progress`, `completed`), and manages discrepancy flags (e.g., if the pilot logs different acres than expected).
*   **`droneController.js`**: Manages the drone fleet inventory. Handles adding, updating, and removing drones, as well as tracking their maintenance status.
*   **`authController.js` & `userController.js`**: Manage the authentication flow (login) and the retrieval of user lists (pilots, admins, sales, etc.).
*   **`systemController.js` / `submitController.js`**: Helper controllers for system-wide operations, including database flushing/seeding.

### 2. Routes (`/backend/routes`)
These files map incoming HTTP requests (GET, POST, PUT, DELETE) to their respective functions inside the `controllers` directory. They keep the `app.js` entry point clean. Examples include `leadRoutes.js`, `assignmentRoutes.js`, etc.

### 3. Data Store (`/backend/data`)
Since there is no actual database attached yet, data persistence is handled via Node's `fs` (File System) module reading and writing to these JSON files:
*   **`leads.json`**: Stores farmer requests.
*   **`assignments.json`**: Stores the mapped relationships between a Lead, a Pilot, and a Drone. Also stores cost and discrepancy data.
*   **`users.json`**: Stores the credentials and roles (`admin`, `sales`, `fleet-manager`, `pilot`) of the platform's users.
*   **`drones.json`**: Stores the hardware inventory and health status.

---

## Frontend Components (`/frontend/src`)

The frontend is a React Single Page Application (SPA) that heavily relies on conditional routing based on the authenticated user's role.

### 1. Routing & State Management
*   **`App.jsx`**: The main entry point. It wraps the app in an `AuthProvider` and defines the `React Router` paths. It uses a custom `<ProtectedRoute>` component to restrict URL access based on user roles.
*   **`AuthContext.jsx`** (inside `/context`): A React Context provider that tracks the currently logged-in user, their role, and their session token in LocalStorage.

### 2. Pages (`/frontend/src/pages`)
These are the primary views corresponding to the different user roles:
*   **`LandingPage.jsx`**: The unauthenticated, public-facing website where farmers submit their details to request a drone spraying service.
*   **`Login.jsx`**: The authentication gateway for staff and pilots.
*   **`MarketingDashboard.jsx` (Sales Rep)**: Displays pending leads. Sales reps use this to verify farmer data and "process" the leads into the system. *(Note: Currently, this component also prematurely assigns pilots, a flaw slated for refactoring).*
*   **`FleetManagerDashboard.jsx`**: Provides a Gantt chart interface for managing drone availability and dispatching pilots to verified leads.
*   **`PilotDashboard.jsx`**: A streamlined view for field operators. Pilots see their active `in_progress` missions here, execute them, and submit the final sprayed acre count to calculate the cost.
*   **`AdminDashboard.jsx`**: The "God View". Admins use this to oversee all operations, manually resolve flagged missions (e.g., cost disputes, drone failures), and monitor system health.
*   **`FlushPage.jsx`**: A hidden developer route (`/flush`) used strictly to reset and populate the JSON database during testing. It operates outside standard Auth rules using a localized password lock.

### 3. Styling
*   **`index.css` & `App.css`**: Contain global Vanilla CSS. The styling methodology currently relies heavily on specific classes like `.glass-card` and `.tilt-effect` to achieve the requested premium, glassmorphism aesthetic.

---

## Identified Architectural Flaws (To Be Refactored)
1.  **JSON File Storage:** The application currently scales poorly due to file-locking and sync issues inherent to writing to static JSON files.
2.  **Role Bleed:** The Sales Dashboard (Marketing) currently handles tasks that belong to the Fleet Manager (e.g., selecting the pilot), while Fleet Management lacks a proper robust calendar scheduler.
3.  **State Assumptions:** Leads bypass the "pending pilot acceptance" state and jump straight to `in_progress`, assuming the pilot is instantly available and in the field.
