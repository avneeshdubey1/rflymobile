# Product Decisions and Production Handoff

**Recorded:** July 13, 2026  
**Scope:** customer-neutral DaaS web application  
**Purpose:** plain-language record of the placeholder, integration, privacy, device-support, and production-hardening decisions agreed after Phase 14.

This document explains what each outstanding item means, what the application does today, what remains to be built, and what information the user or operating company must provide later. It contains no credentials. Never copy values from `.env`, passwords, API keys, signing secrets, payment credentials, or reset codes into this file.

## Current outcome

- The active product remains customer-neutral. No R-fly or other customer-specific branding is approved.
- Bhumeet-specific code has been removed from the active frontend and backend and isolated in `docs/deferred/bhumeet.md` for possible future discussion.
- New GPS audit events do not contain latitude or longitude.
- Unread chats remain open indefinitely; fully read inactive chats close after 24 hours; a participating Admin can close a chat for both sides.
- Password recovery is planned as WhatsApp first, with SMS and email fallbacks.
- Audit records currently have no automatic deletion.
- Current device scope is modern Android and desktop browsers. iOS is deferred.
- The repository has a mandatory production checklist in `production hardening.md`, and root `AGENTS.md` instructs future coding agents to follow it.
- The Admin role is planned as the highest in-application operational role. Hardening will give it auditable monitoring and controlled management of all company business records, while keeping database credentials, provider secrets, password hashes, raw SQL, and audit-log rewriting out of the browser.
- The application can be used as a controlled development demonstration, but it is not approved for production or real customer data until the hardening register is completed.

## 1. JWT signing secret

### Simple explanation

The JWT secret is the server's private signing key for login tokens. It acts like a private stamp: the backend signs a user's login token, and later checks the stamp to confirm that the token was created by the backend and was not altered.

This is not something to purchase from a vendor. Generate it locally on the deployment machine:

```powershell
node -e "console.log(require('node:crypto').randomBytes(48).toString('base64url'))"
```

Store the output in `backend/.env` or, preferably for production, the hosting provider's secret manager:

```env
JWT_SECRET=generated-value-here
```

### Security rule

Do not send the secret to a coding agent, paste it into chat, add it to documentation, commit it to Git, or print it in logs. Anyone who obtains it may be able to forge login tokens, including an Admin token. If it is ever exposed, generate a replacement and invalidate existing sessions.

### Current application behavior

`backend/middleware/auth.js` uses a known development-only fallback if `JWT_SECRET` is absent. That is acceptable only for local demonstration. Production must refuse to start when a strong secret is not configured.

## 2. Branding and customer neutrality

The current customer may be R-fly, but the product is not approved as an R-fly-branded application. Do not add a customer name, logo, proprietary colours, domain, photographs, or customer-specific wording unless the user explicitly requests it later.

The current interface is visually neutral. However, a neutral interface is not the same as a multi-customer platform. The database currently behaves as one fleet operator's system. Before multiple companies use the product, the company must choose one of these deployment models:

1. A separate application and database for each customer; or
2. One shared application with true tenant isolation added to every database record, repository query, API, socket room, background job, cache, and audit query.

Multiple companies must never share the current single-operator database without this decision and implementation.

## 3. Logs and alerts

### What is a log?

A log is the application's operational diary. It records that an event happened, when it happened, whether it succeeded, and the relevant internal IDs. Production logs should not contain passwords, API keys, farmer phone/address data, payment payloads, chat content, reset codes, or exact GPS coordinates.

Useful log events include:

- Google Form intake accepted, rejected, duplicated, or failed.
- Automatic assignment succeeded or moved to manual scheduling.
- The pilot notification cascade advanced, failed, or stopped running.
- A database health check failed.
- Weather information was unavailable.
- WhatsApp, SMS, email, or payment delivery failed.
- Authentication failures increased unexpectedly.
- A scheduled background job's heartbeat became stale.

### What is an alert?

An alert turns an important log or unhealthy condition into a notification for a responsible person. A dashboard alone is not sufficient if nobody is notified.

Recommended alerts include:

- Database or `/api/health` unavailable.
- Notification or chat-cleanup job heartbeat stale.
- Repeated Google intake failures.
- A growing manual-scheduling or failed-notification backlog.
- Weather-provider outage or quota exhaustion.
- WhatsApp template/delivery failures.
- Payment webhook verification or reconciliation failures.
- Elevated login failures or suspicious authorization errors.
- Backup failure or unusual database/disk growth.

The company must later provide alert recipients, severity levels, working-hours/on-call rules, escalation order, acknowledgement expectations, and log-retention duration.

## 4. Password reset policy

Password recovery must support:

1. WhatsApp as the default channel.
2. SMS as the first fallback.
3. Email as another fallback.

This is a recorded product decision, not a completed feature. A safe implementation needs verified phone/email ownership, short-lived one-time reset tokens or codes, request and attempt rate limits, generic responses that do not reveal whether an account exists, audit events without codes, and forced logout/revocation after a successful reset.

Real delivery requires WhatsApp, SMS, and email provider accounts. Passwords must also be moved from direct comparison/storage to an approved password hash before production.

## 5. Pricing and operating thresholds

Production prices and operating thresholds belong to the operating company, not the developer. This includes:

- Spray price per acre.
- Out-of-range transport price.
- Geofence radius.
- Acreage discrepancy percentage.
- Wind threshold.
- Rain-probability threshold.
- Compliance grace windows.

The current application correctly reads development values from configuration rather than embedding them directly in the business logic. Before real operations, the company must approve the actual values and the application needs authorized, validated, audited Admin screens/APIs to manage them.

## 6. Pilot, drone, centre, and DGCA administration

The database already contains fields for pilot licence expiry and drone airworthiness expiry. The application is not yet a complete administration system for these values.

### What exists now

- Admin can list employees and drones.
- Drone status and maintenance actions exist.
- Sample pilots, drones, centres, and compliance dates can be created through development seeding.
- The schema can store licence and airworthiness expiry dates.

### What is incomplete

- The current pilot-creation form is incomplete and not production-safe.
- Password handling for created users is unsafe for production.
- There is no complete create/edit/activate/deactivate pilot workflow.
- There is no Admin workflow to create or fully edit drones.
- There is no proper interface to manage operating centres, service radii, licence records, or airworthiness records.

Production hardening must add secure and audited Admin workflows for pilots, drones, centres, compliance dates, status, and configuration. The company will enter the real values later. The agreed direction is an Admin Operations Control area: an Admin can search, monitor, and perform controlled create/edit/deactivate/archive actions across company leads, assignments, payments, chats, alerts, people, drones, centres, and configuration. Password hashes, deployment/provider secrets, direct database access, and changes to append-only audit history remain outside that browser role.

## 7. Weather API options

The application currently expects a provider adapter that returns wind speed in kilometres per hour and precipitation probability for each candidate day. It examines up to five days when selecting a mission date. If weather is unavailable, scheduling continues with a visible Fleet Manager warning; it does not fail silently or block the lead.

### Suggested providers

#### OpenWeather — recommended starting point for the demo

OpenWeather's published free access includes current weather, a five-day/three-hour forecast, 60 calls per minute, and one million calls per month. This matches the application's current five-day scheduling window better than a three-day plan.

Official page: <https://openweathermap.org/price>

#### WeatherAPI

WeatherAPI publishes a free plan with 100,000 calls per month and permits commercial use, but its free forecast window is three days. Its published Starter plan expands the forecast window, but prices and terms must be rechecked when a provider is selected.

Official page: <https://www.weatherapi.com/pricing.aspx>

#### Open-Meteo

Open-Meteo's free/open-access endpoint is intended for non-commercial evaluation and prototyping. Commercial use requires a subscription/customer endpoint. It is useful for evaluation but should not be assumed to be a free production provider.

Official page: <https://open-meteo.com/en/pricing>

#### India Meteorological Department

IMD publishes official Indian weather APIs and documentation. Its site refers to IP whitelisting, attribution, and caching guidance. Access, suitability, support, and any applicable commercial terms should be confirmed directly with IMD.

Official page: <https://mausam.imd.gov.in/responsive/apis.php>

### What the user must do

Choose a provider and create its account/key through the provider's official site. Put the key directly into the local/deployment secret store as `WEATHER_API_KEY` if the selected provider uses one. Do not send the value through chat. Tell the developer which provider was chosen and that the variable is configured; the developer must still build and test the provider-specific adapter.

## 8. Google Form intake

The backend contains authenticated and idempotent Google Form webhook intake, but no real Google Form or Sheet has been connected.

The Google Workspace/operations owner must later provide:

- The real Form and response Sheet owner.
- Exact question/column-to-lead-field mapping.
- The deployed backend URL.
- An Apps Script `onFormSubmit` connection.
- A `FORM_WEBHOOK_SECRET`, entered directly into the secret store.

Duplicate delivery, timeout, retry, changed columns, and failure-alert behavior must be tested before live use.

## 9. Deferred Bhumeet work

Bhumeet is not integrated into the active application. The following were removed:

- Admin dashboard tab and mock data view.
- Frontend API calls.
- Express route and controller.
- External login helper.
- Root connectivity test.

Only a credential-free future note remains at `docs/deferred/bhumeet.md`. It must not be reactivated unless the user explicitly reopens the topic.

The removed root test contained a plaintext external credential. If it was ever a valid credential, it must be rotated immediately. Deleting a file does not invalidate a password that may exist in Git history, backups, screenshots, or copied workspaces.

## 10. WhatsApp integration

Lifecycle message templates and safe mock delivery already exist. Without a provider, the application records a mocked delivery and continues the operational workflow.

Live integration later requires:

- WhatsApp Business account and approved sending number.
- Provider choice and credentials.
- Farmer opt-in evidence.
- Approved templates for all five supported languages.
- Verified delivery-status webhook.
- Handling for rejected templates, failed delivery, expired conversation windows, quota limits, and provider downtime.

Credentials must be entered directly into the secret store, not sent through chat.

## 11. UPI integration

Mission completion already creates a pending payment record. Without a gateway, the application visibly falls back to cash/manual collection and does not fabricate a UPI link.

The customer/company must later supply the legal merchant/gateway account, settlement-bank information, merchant descriptor, refund and reconciliation rules, and business ownership. Development must then implement signed, replay-safe/idempotent webhooks and complete sandbox testing before handling live money.

## 12. Language review

English, Tamil, Kannada, Telugu, and Hindi work technically in the interface and message-template system. The business wording—particularly Kannada, Telugu, Hindi, regional agriculture terms, consent text, and payment text—remains provisional.

A multilingual reviewer should approve every farmer-facing string after the WhatsApp provider and template format are selected. Technical support for a language does not prove that the wording is culturally or operationally correct.

## 13. GPS and privacy

### What happens now

- The browser/Android device supplies location through its normal location permission; no separate GPS API account is required.
- Only the pilot assigned to the mission can submit location.
- Submission is allowed only while the mission is accepted or in progress.
- Fleet Managers and Admins can view the latest point.
- Default capture cadence is 60 seconds.
- The assignment stores only the latest latitude, longitude, and ping time rather than a route trail.
- New append-only GPS audit events record the assignment, timestamp, and that a location was received, but not the coordinates.
- A database inspection after the correction found zero existing GPS audit rows containing coordinates.

### Decisions and inputs still required

- Privacy owner/contact name and email.
- Approved plain-language pilot notice.
- Confirmation or change of the 60-second cadence.
- Confirmation that Admin and Fleet Manager are the only viewer roles.
- Exact deletion time for the final stored coordinate. Erasing it at mission completion is the privacy-minimizing recommendation; a short operational grace period is another possible company decision.
- Behavior when permission is denied, revoked, unavailable, or inaccurate. This must be visible to operations and must not silently pretend tracking works.
- Data access, correction, deletion, and incident-response ownership.

Before real tracking, the application should record the pilot's acknowledgement of a versioned notice, its timestamp, and re-consent/withdrawal state. Browser permission by itself should not be treated as the entire informed-notice process.

## 14. Browser and device support

The current target is modern Android browsers and modern desktop browsers. iOS and native app-store packaging are deferred.

It is not realistic to promise “every browser” without testing exact versions and devices. Acceptance testing should record Android and desktop browser/device versions and cover:

- Airplane mode and intermittent data.
- Backgrounding and reopening.
- Browser/device restart.
- Permission denied/revoked.
- Shared devices and logout.
- IndexedDB/offline queue replay.
- Low memory and poor network conditions.

## 15. Audit retention

There is currently no automatic audit deletion, so the interim policy is indefinite retention. Exact coordinates are excluded from new GPS audit events.

Indefinite retention is a company decision for now, not proof of legal compliance. Before production, the company must still decide who may view/export audit history, which fields need redaction, storage and backup costs, handling of deletion/access requests, and whether a later archive/deletion policy is required.

## 16. Chat lifecycle

The implemented policy is:

- An unread chat remains open indefinitely.
- A chat becomes eligible for automatic closure only when all messages have been read.
- A fully read chat closes after 24 hours without activity.
- A participating Admin can close the chat immediately for both participants.
- Manual closure is sent live to both sides.
- Closed chats remain readable but cannot receive new messages.
- Session creation, messages, reads, automatic closure, and Admin closure are audited without copying message content into the audit log.

The current manual-close permission belongs to the Admin participating in that conversation. A future global support-supervisor role would require a separate explicit permission decision and tests.

## Immediate user action

The only urgent external action discovered during this work is credential rotation: if the plaintext credential removed with the Bhumeet connectivity test was ever valid, rotate it now.

Do not send a JWT secret, weather key, WhatsApp key, UPI credential, webhook secret, or password to the developer. Enter secrets locally or in the deployment provider and state only that the named environment variable has been configured.

## Demonstration versus production

### Controlled demonstration

The application can be demonstrated locally with PostgreSQL and the documented mocks/fallbacks. The demonstration must clearly identify weather, WhatsApp, Google Form, and UPI as placeholders where they are not connected.

### Production

The application is not production-ready yet. Major blockers include password hashing/reset, route authorization review, tenant/deployment isolation, Admin management for operational records, GPS consent and deletion, live provider verification, backups/restores, monitoring/alert routing, secure hosting/CORS/HTTPS, and device/end-to-end acceptance testing.

The authoritative release checklist is `production hardening.md`.

## Verification recorded with these decisions

- Backend automated tests: 23 passed, 0 failed.
- New chat tests prove read-chat auto-close, unread-chat retention, Admin-only manual closure, and bilateral live closure.
- GPS tests prove new audit state has no latitude or longitude.
- Prisma schema validation passed.
- Frontend lint passed.
- Frontend production build passed.
- The build retains a non-blocking advisory about a large JavaScript bundle; it is a performance follow-up, not a build failure.
- Database inspection found zero existing coordinate-bearing GPS audit records after test cleanup.

## Related documents

- `current placeholders.md` — live placeholder/integration register.
- `production hardening.md` — mandatory production checklist and decision register.
- `history_of_changes.md` — chronological implementation history.
- `AGENTS.md` and `docs/AGENTS.md` — future coding-agent instructions.
- `docs/deferred/bhumeet.md` — isolated future note; not part of the active application.
