# Demo Acceptance Report — July 14, 2026

## Outcome

**Disposition: viable for a controlled local stakeholder demonstration. Not approved for production or an internet-accessible customer deployment.**

The repair pass closed every defect that failed the July 14 browser audit. A production frontend build was driven through Microsoft Edge against isolated Express/PostgreSQL processes and a disposable database. The normal demonstration database was not seeded or mutated by either automated suite.

## Verification summary

| Check | Result |
|---|---:|
| Edge browser workflows | 30/30 passed |
| Backend automated checks | 26/26 passed |
| Frontend ESLint | Passed |
| Frontend production build | Passed |
| Prisma schema validation | Passed |
| Unexpected browser runtime exceptions | 0 |
| Unexpected normal-flow console/HTTP errors | 0 |

Machine-readable browser results and per-workflow screenshots are stored in `docs/test-evidence/browser-audit-2026-07-14/`. The browser suite uses `rfly_daas_browser_test`; the backend suite uses `rfly_daas_backend_test`. Both databases are reseeded independently on each run.

The invalid-login case deliberately produces one traced `POST /api/auth/login` HTTP `401`; the harness allows that one expected security response and fails every unexpected browser console error.

## Emergency UI correction coverage

- Replaced the conflicting page-level dark/white themes with one customer-neutral operations design system.
- Added a shared role shell and icon system for Admin, Sales, Fleet Manager, and Pilot workspaces.
- Reworked public intake, login, fleet overview, user management, lead processing/manual entry, appeal review, exception scheduling, pilot mission controls, CRM, support chat, payments, live GPS, dialogs, empty states, and the not-found route.
- Removed 232 JSX inline style objects; there are now no inline style objects or legacy page-root colour conflicts in active JSX.
- Verified every Admin and Sales tab at `390 × 844`, Pilot missions/chat and employee login at `390 × 844`, and Fleet calendar/GPS at `768 × 1024`, with no page-level horizontal overflow.
- Disabled service-worker caching during Vite development and versioned production caches so stale assets cannot preserve the previous interface.
- Forced the Sales live-update socket to WebSocket transport; the unexplained polling HTTP `400` no longer occurs.

The detailed design/root-cause record is `docs/ui_correction_report_2026-07-14.md`.

## Browser workflows completed

### Public and intake

- Five-language switching for English, Tamil, Kannada, Telugu, and Hindi.
- Responsive 390 × 844 layout without horizontal overflow.
- Accessible names for every public form control.
- In-range GPS submission persisted as a `NEW` lead.
- Out-of-range GPS submission displayed an appeal offer and persisted the appeal.
- Client and server rejected an alphabetic phone number.
- Client and server rejected negative acreage.

### Authentication and authorization

- Anonymous visits to all four protected dashboards redirected to login.
- Invalid login failed without revealing a development password.
- Admin, Sales, Fleet Manager, and Pilot reached only their intended dashboard.
- Anonymous user/drone reads and mutations returned `401`.
- Wrong-role management operations returned `403`.
- User and nested assignment responses contained no `passwordHash` field.

### Operations

- Sales saw a new website lead and submitted a verified manual lead through auto-assignment.
- Sales approved an out-of-range appeal through the new review queue.
- Fleet manually scheduled a `NEEDS_MANUAL_SCHEDULING` lead with a free same-centre pilot/drone.
- Admin fleet totals matched `AVAILABLE`/`ASSIGNED` database statuses.
- Admin created a role account with a hashed password.
- Pilot accepted, started, published GPS, and completed a mission without a transition-time GPS `409`.
- Pilot offline acceptance queued in IndexedDB and replayed after reconnection.
- Mission completion created a payment; Sales used the visible no-UPI fallback and recorded cash collection.
- Admin opened the completed lead’s full CRM/audit timeline.
- Admin and Pilot exchanged live messages; Admin closure propagated to both participants.
- Health reported PostgreSQL plus notification/chat job heartbeats as healthy.

## Defects closed from the initial audit

| Initial defect | Repair |
|---|---|
| Anonymous user/drone APIs | Authentication plus Admin/Fleet role gates on every management route; negative role tests added. |
| Credential material in responses | Safe repository projections, safe assignment/escalation relations, sanitized audit serialization, and bcrypt storage. |
| Sales could not see `NEW` leads | Sales now uses the Prisma status model and renders persisted lead field names. |
| Repeated Sales assignment `403`s | Replaced forbidden `/assignments/all` polling with a limited Sales alerts endpoint. |
| Admin employee creation failed | Work-email model, normalized roles, validated password, visible success/error state, and bcrypt persistence. |
| Invalid phone/acreage persisted | Client constraints plus server normalization, positive acreage, and a configuration-driven maximum. |
| Login exposed demo credentials | Removed all visible demo identifiers/passwords and neutralized the login placeholder. |
| Admin fleet showed false totals | Mapped `AVAILABLE`, `ASSIGNED`, `MAINTENANCE`, and `OUT_OF_SERVICE` correctly. |
| Public controls lacked label association | Added stable `id`/`htmlFor` relationships and alert/status roles. |
| GPS sent during mission transitions | Paused GPS while online mission-state requests are in flight. |
| Sales appeal operations gap | Added record/approve/reject controls with authenticated reviewer identity and validated fee. |
| Backend fixtures polluted demo data | Added disposable backend test DB, self-owned Phase 1 fixtures, Phase 7 cleanup, and a development residue cleaner. |

## Deliberate demo limitations

These are visible, documented placeholders rather than silent failures:

- WhatsApp delivery remains mocked and audited.
- Weather remains fail-open with an operations warning when no provider is configured.
- UPI remains unavailable and visibly falls back to cash/manual collection.
- Google Form/Apps Script is not connected to a real form.
- Password recovery, full Admin configuration, multi-company isolation, GPS consent/retention approval, backups/restore, monitoring/alerts, and provider hardening remain production blockers.
- Five-language wording still requires native-speaker/business approval.

## Reproduction

Follow the local commands in the root `README.md`. The complete regression commands are:

```powershell
cd backend
npm test
npm run prisma:validate

cd ..\frontend
npm run lint
npm run build
npm run test:browser
```

Passing this local gate demonstrates the implemented workflows; it does not replace physical Android testing, cross-browser testing, penetration/load testing, provider sandboxes, privacy approval, or the remaining checks in `production hardening.md`.
