# Hardening Pause and Restart Handoff

**Paused:** July 14, 2026  
**Reason:** the user requested an immediate stop after running out of credit.  
**Active application:** `D:\projects\Daas--main\Daas--main`  
**Release status:** not production-ready. Do not treat the interrupted H2 work as a completed authentication change.

## Exact stopping point

All delegated workstreams have stopped. No hardening agent is still running.

The last fully verified checkpoint is the end of H1. H2 was interrupted after its database schema, migration, and repository scaffolding were added, but before the authentication controllers, routes, browser session handling, account-recovery workflow, and tests were implemented. H3 through H7 were not started.

| Phase | State at pause | Safe interpretation |
|---|---|---|
| H0 - privacy/device containment and GPS presentation | Implemented and verified | Completed local hardening checkpoint |
| H1 - HTTP, Socket.IO, and webhook perimeter | Implemented and verified | Completed local hardening checkpoint |
| H2 - revocable cookie sessions and account recovery | **Partially written; unverified** | Resume here; do not deploy or call it complete |
| H3 - transactions, idempotency, concurrency, money safety | Not started | Pending |
| H4 - complete Admin Operations Control | Not started | Pending |
| H5 - GPS consent, collection lifecycle, and retention | Not started | Pending |
| H6 - integrations, observability, containers, and operations | Container/CI/runbook files drafted; full phase not implemented or verified | Pending |
| H7 - final release and device-quality gate | Not started | Pending |

## Work completed before the pause

### H0 - privacy, shared-device safety, and map presentation

- Exact GPS coordinates, farmer contact data, payment links, chat content, and credentials are stripped from generic append-only audit snapshots by `backend/src/repositories/auditLogRepository.js`.
- `backend/scripts/redactAuditSnapshots.js` was run against the local database. It redacted 20 of 143 legacy audit records; the follow-up scan found zero remaining coordinate/contact-key matches.
- `frontend/public/sw.js` now caches only the application shell and safe static resources. It excludes `/api`, Socket.IO, authenticated/private responses, and cross-origin responses.
- `frontend/src/services/offlineActionQueue.js` now scopes queued work to the authenticated user, expires it after 24 hours, limits queue size, clears the user's queue on logout, and coalesces GPS pings per assignment with capture time and accuracy metadata.
- `frontend/src/components/LocationLink.jsx` and `frontend/src/utils/locationPresentation.js` prevent raw coordinates from being rendered as visible text. The visible label uses known operational context such as an address, operating centre, farmer, or pilot; the link opens the exact point in Google Maps.
- `frontend/src/components/LiveLocationPanel.jsx` provides the Admin/Fleet live pilot view. The OpenStreetMap frame is click-to-load, the live marker updates from Socket.IO data, and the UI explains that loading an external map shares the exact location with the map provider.
- No silent reverse-geocoding service was invented. Showing an actual nearest-building name when the application has no address still requires a company-approved geocoding provider and its privacy/usage decision.

Verification recorded at this checkpoint:

- Combined H0/H1 backend suite: 39/39 passed.
- H0 privacy/location-focused checks: 7/7 passed.
- Frontend lint and production build passed; only the existing bundle-size advisory remained.
- Prisma validation passed.

### H1 - production perimeter controls

- `backend/config/environment.js` validates deployment origins, proxy/HTTPS settings, request limits, rate limits, map-frame origins, and webhook configuration. Production configuration fails closed for unsafe values.
- `backend/middleware/httpSecurity.js` adds request IDs, no-store API caching, security headers/CSP/HSTS, credentialed CORS allowlisting, HTTPS enforcement, body/type limits, rate limiting, and non-sensitive error responses.
- `backend/config/socketSecurity.js` adds Socket.IO origin, connection-rate, event-rate, and payload-size controls.
- `backend/middleware/webhookSecurity.js` adds timing-safe secret comparison and timestamp/event replay checks. Google Form and UPI endpoints fail closed in production when verification is absent.
- Public health output is status-only; detailed health data is restricted to Admin.
- `backend/tests/hardening-h1-perimeter.test.js` added ten focused perimeter tests; all ten passed.

Known H1 follow-up: webhook replay tracking is currently process memory, so H3 still needs a durable database event ledger for restarts and multiple backend containers. UPI must also move from a static shared header to the selected gateway's signed-body verification scheme.

### Isolated container/operations foundation drafted during H6 preparation

The following files were written before the stop:

- `compose.production.yml`
- `backend/Dockerfile`, `backend/.dockerignore`, and `backend/docker/entrypoint.sh`
- `frontend/Dockerfile`, `frontend/.dockerignore`, and `frontend/docker/*`
- `.github/workflows/ci.yml`
- `deploy/example.env` and `deploy/README.md`
- `docs/operations/deployment.md`
- `docs/operations/migration-rollback.md`
- `docs/operations/backup-restore.md`
- `docs/operations/incident-response.md`

The intended model is one isolated Compose project, PostgreSQL database/volume, secret set, and domain per customer. The database has no published host port, and only the frontend reverse proxy is exposed. A second customer must get a separate stack and database; this is not shared-database multitenancy.

**These container and CI assets were not fully validated before the pause.** They still reference the existing JWT secret because H2 did not finish. Do not use them as production evidence until H2 is completed, their secret contract is updated, `docker compose config` passes, images build, the isolated stack starts, migrations complete, and the health/security checks pass.

## H2 work that is present but incomplete

The following scaffolding landed:

- `User.active`, `User.authVersion`, verified email/phone timestamps, and `archivedAt` fields in `backend/prisma/schema.prisma`.
- `AuthSession` for hashed opaque session tokens, hashed CSRF tokens, idle/absolute expiry, and revocation.
- `PasswordRecoveryChallenge` for hashed, expiring, one-time recovery challenges with attempt limits.
- Migration `backend/prisma/migrations/20260714094500_identity_sessions_recovery/migration.sql`.
- `backend/src/repositories/authSessionRepository.js`.
- `backend/src/repositories/passwordRecoveryRepository.js`.

The following H2 requirements are **not implemented yet**:

- The migration was not confirmed as applied in this interrupted workstream.
- Login still returns the older bearer token, and the frontend still places the token/user in `sessionStorage`.
- There is no host-only HttpOnly session cookie, Secure production cookie, SameSite policy, CSRF cookie/header enforcement, `/me`, logout, or logout-all flow.
- API and Socket.IO authentication do not yet use/revalidate `AuthSession` on every request/connection.
- Password reset, user deactivation, and role changes do not yet revoke all sessions through the new design.
- The generic, non-enumerating recovery request/verification/reset endpoints do not exist.
- WhatsApp-first recovery with verified SMS/email fallback and a provider adapter does not exist.
- Recovery UI, recovery audit events, rate/attempt tests, shared-device tests, and production fail-closed tests do not exist.
- The container/CI secret configuration has not been updated from JWT to the completed H2 session model.
- No full test, lint, build, Prisma, browser, or container rerun was made after these partial H2 files landed.

This means the current working tree is an intermediate development state. Resume H2 before evaluating or demonstrating this version.

## Work still required

### Finish H2 - authentication and recovery

1. Review the unfinished schema/migration and check migration status without assuming it was applied.
2. Implement opaque database-backed sessions stored only in host-only HttpOnly cookies, with idle and absolute expiry, revocation, active-user/auth-version checks, and CSRF protection for mutations.
3. Convert browser fetch and Socket.IO clients away from bearer tokens/session storage; preserve user-scoped offline-queue cleanup on logout.
4. Add `/me`, logout, logout-all, password-reset revocation, role/deactivation revocation, and negative permission tests.
5. Implement generic WhatsApp-first recovery with only verified destinations, SMS/email fallback eligibility, hashed one-time codes, rate/attempt limits, expiry, audit events, mock injection for tests, and production failure when no approved delivery adapter exists.
6. Update Docker/CI secrets and run the complete regression suite.

### H3 - data correctness and payment safety

- Wrap assignment, mission transitions, drone reservation/release, payment, audit, and notifications in database transactions.
- Add database-safe resource reservation and concurrency tests so one pilot/drone cannot be double-booked.
- Add durable idempotency records for public/pilot mutations and a durable provider-event replay ledger.
- Make cash-versus-webhook settlement atomic and enforce one payment per assignment.
- Replace `Float` money fields with Decimal or integer minor units, with a migration and serialization tests.
- Add distributed-safe claiming/leases for scheduled jobs and restart/failure tests.
- Centralize strict input validation, including rejecting null/empty/non-finite coordinates instead of converting them to zero.

### H4 - Admin Operations Control

- Add searchable, paginated, audited Admin management for users/pilots, drones, operating centres/radii, leads, assignments, all payments, chats, alerts, and business configuration.
- Support create/edit/deactivate/archive/retire instead of hard deletion, with required reasons and confirmation for sensitive actions.
- Add pilot licence and drone airworthiness/maintenance history management.
- Add versioned/effective-dated pricing, weather, discrepancy, and compliance configuration so historical jobs are not silently rewritten.
- Keep the security boundary: no raw SQL, database/provider credentials, password hashes, secret values, or audit-log rewriting in the browser.
- Add permission, audit, state-guard, pagination, and concurrent-override tests.

### H5 - GPS consent and retention

- Add a versioned plain-language pilot notice and persisted acknowledgement/withdrawal state before asking the browser for GPS permission.
- Record capture time/accuracy, reject stale pings, and restrict tracking to the assigned pilot's active mission.
- Decide and enforce exact-coordinate deletion at completion/cancellation (recommended privacy default: immediate deletion, with only coordinate-free audit evidence retained).
- Show denied/revoked/offline states and test logout, shared devices, backgrounding, reconnects, and permission changes.
- Obtain the company's privacy owner/contact and approved notice/cadence/retention wording before real tracking.

### H6 - integrations and production operations

- Finish and verify the container/CI assets listed above.
- Implement provider-neutral delivery/outbox states, retries/backoff/timeouts, visible failure queues, and delivery-status handling.
- Add graceful shutdown for HTTP, Socket.IO, jobs, and Prisma; readiness based on database and job freshness; stronger redacted structured logs; metrics and external-monitoring hooks.
- Prove migration, rollback, backup, and restore procedures using disposable infrastructure.
- Real Google, weather, WhatsApp, SMS/email, and UPI activation remains blocked until the company supplies approved sandbox accounts/configuration through a secret store.

### H7 - release gate

- Rerun all backend tests, Prisma validation/migrations, frontend lint/build, and every role workflow in the browser.
- Add replay, duplicate, database/job restart, low-bandwidth, provider timeout/quota, accessibility, localization, timezone, and currency tests.
- Run dependency, static-code, and secret scans without printing discovered secrets. Rotate the previously exposed Bhumeet credential externally even though its active code was removed.
- Build/start the isolated container stack and preserve evidence.
- Record real Android and desktop Chrome/Firefox/Edge versions/devices. iOS remains deferred.
- A production claim additionally requires company hosting/TLS, backup RPO/RTO, alert ownership, provider approvals, privacy approval, and production-like staging evidence.

## External decisions and inputs still needed later

- Privacy owner/contact and approved GPS notice, cadence, viewers, and deletion policy.
- Hosting region/domain/TLS/proxy topology, expected load, monitoring recipients, escalation path, and backup RPO/RTO/destination.
- Company-approved operating centres/radii, pricing, weather, compliance, pilot licence, and drone airworthiness values.
- Sandbox/provider accounts for Google Form, weather, WhatsApp, SMS/email, and UPI. Secrets must be entered directly into a local/deployment secret store and must not be pasted into project documentation or chat.
- Five-language review and the final supported Android/desktop device matrix.

## Safe restart order

1. Read this file, `production hardening.md`, `current placeholders.md`, and `AGENTS.md`.
2. Inspect the dirty working tree and preserve unrelated user changes; no hardening commit was created at this pause.
3. Resume **H2**, not H3. Confirm migration/database state before applying or changing the H2 migration.
4. Complete H2 and update the Compose/CI secret contract.
5. Run backend tests, Prisma validation, frontend lint/build, and browser authentication/shared-device checks.
6. Continue H3 through H7 in order, updating `history_of_changes.md`, `current placeholders.md`, and `production hardening.md` only when verified evidence exists.

