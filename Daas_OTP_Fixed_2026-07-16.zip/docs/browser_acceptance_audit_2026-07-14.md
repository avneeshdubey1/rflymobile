# Browser Acceptance and Regression Audit — July 14, 2026

> Historical pre-repair audit. Its 14/24 result has been superseded by the completed repair run in `docs/demo_acceptance_report_2026-07-14.md` (25/25 browser workflows and 26/26 backend checks passed). The original findings remain below to preserve why each repair was made.

## Executive result

**Current disposition: not ready for production or an externally accessible demo.**

The application now renders and several end-to-end workflows work, but the audit found critical authorization/data-exposure defects and a broken primary Sales processing view.

| Check group | Result |
|---|---:|
| Browser/API acceptance checks | 24 |
| Passed | 14 |
| Failed | 10 |
| Frontend lint | Passed |
| Frontend production build | Passed; existing large-bundle advisory only |
| Prisma schema validation | Passed |
| Backend suite | All 23 assertions executed in one run: 22 passed and the seed-status assertion failed because the browser run had consumed its fixture. After reseeding, that assertion passed, but the suite intermittently left the Phase 7 worker open and did not terminate. Treat the suite as not clean until fixture isolation and the open handle are fixed. |

Passing a build is not equivalent to rendering successfully in a browser. This audit drives a real installed browser and captures runtime errors, responses, persisted state, responsive layout, and cross-role behavior.

## Test environment and isolation

- Browser: Microsoft Edge 150.0.4078.65, headless, with a fresh context for each case.
- Frontend: Vite production build served on an isolated test port.
- Backend: separate Express/Socket.io process on an isolated test port.
- Database: dedicated PostgreSQL database `rfly_daas_browser_test` in the existing Docker container.
- The normal development database was not seeded, cleared, or used by this audit.
- Test-user passwords and the JWT signing secret were generated in memory for each run and were not written to the report or fixtures.
- External WhatsApp, weather, UPI, and Google credentials were not used. Existing mock/fail-open behavior remained active.

Repeatable command:

```powershell
cd frontend
npm run test:browser
```

This command resets only `rfly_daas_browser_test`. It requires the local `rfly-postgres` Docker container and Microsoft Edge at the standard Windows installation path.

## Passed workflows

| ID | Workflow | Verified outcome |
|---|---|---|
| PUB-01 | Five-language landing page | English, Tamil, Kannada, Telugu, and Hindi all switched visibly with distinct submit text. |
| PUB-02 | Mobile layout | At 390 × 844 the landing page had no horizontal overflow. |
| PUB-04 | In-range website intake | Browser GPS was collected, geofencing matched an operating centre, and a `NEW` lead persisted. |
| PUB-05 | Out-of-range intake and appeal | The distance/fee offer appeared and the farmer could submit the appeal. |
| AUTH-01 | Protected frontend routes | Anonymous visits to Admin, Sales, Fleet, and Pilot routes redirected to login. |
| AUTH-03 | Role login/routing | Admin, Sales, Fleet Manager, and Pilot authenticated and reached their role dashboards. |
| SALES-02 | Manual Sales intake | The Sales form created a lead from a Maps/GPS-formatted location. |
| FLEET-01 | Manual exception scheduling | Fleet selected a pilot and scheduled a `NEEDS_MANUAL_SCHEDULING` lead with an available centre drone. |
| PILOT-01 | Mission lifecycle and live GPS | Pilot accepted, started, published GPS, Fleet saw the coordinate, Pilot completed, and a payment record was created. |
| PILOT-02 | Offline replay | An acceptance action queued in IndexedDB while offline and synchronized after reconnection. |
| PAY-01 | Payment fallback | Sales saw the completed mission, received the explicit no-UPI-provider fallback, and recorded cash collection. |
| CRM-01 | Audit/CRM timeline | Admin opened the completed lead and saw its combined lifecycle history. |
| CHAT-01 | Admin–Pilot live chat | Both roles exchanged messages; Admin closed the chat and Pilot received bilateral closure. |
| OPS-01 | Health endpoint | PostgreSQL and both scheduled-job heartbeats reported healthy. |

## Failed browser checks

### Critical

#### SEC-01 — User and drone management routes have no backend authorization

Evidence:

- Anonymous `GET /api/users/all` returned HTTP 200 instead of 401.
- Anonymous `GET /api/drones/all` returned HTTP 200 instead of 401.
- Anonymous `POST /api/users/add` created a user with HTTP 201.
- Anonymous `POST /api/drones/update-status` changed a drone with HTTP 200.

Affected code: `backend/routes/userRoutes.js:5-12`, `backend/routes/droneRoutes.js:5-10`.

Impact: anyone who can reach the backend can enumerate personnel/fleet data, create accounts, change passwords, delete users, and alter drone state without logging in. Frontend route protection does not mitigate direct API access.

Required correction: add authentication and Admin/Fleet role authorization to every management route, then add negative tests for every role and anonymous caller.

#### SEC-02 — User APIs return `passwordHash`

Evidence: authenticated `GET /api/users/all` returned a `passwordHash` property for all 11 test users.

Affected code: `backend/controllers/userController.js`, `backend/src/repositories/userRepository.js`.

Impact: credential material is exposed to API clients. In this development build the values are also compared/stored directly rather than being production password hashes.

Required correction: select/serialize only safe fields, hash stored passwords, and ensure create/edit/list/login responses never return credential fields.

### High

#### SALES-01 — New website leads do not appear in the Sales processing queue

Evidence: the API returned the newly created lead with status `NEW`, but the Sales page never displayed it.

Root causes:

- `frontend/src/pages/MarketingDashboard.jsx:140` filters for lowercase legacy status `pending` instead of Prisma status `NEW`.
- The same page requests `/api/assignments/all` at line 42 even though Sales is forbidden from that route, producing repeated HTTP 403 responses every five seconds.

Impact: the normal website → Sales processing → auto-assignment workflow cannot be completed through the Sales UI.

Required correction: use the server status model consistently and provide a Sales-authorized notification/summary endpoint instead of calling Fleet/Admin assignment data.

#### ADMIN-01 — Admin employee creation is broken

Evidence: the browser submitted the Admin form and received HTTP 400: `email, name, and a valid role are required`.

Root cause: the UI sends lowercase `pilot`/`sales`, while the backend accepts `PILOT`/`SALES`; the UI also presents an employee ID as the email identifier.

Affected code: `frontend/src/pages/AdminDashboard.jsx:20-66`, `backend/controllers/userController.js:7-12`.

Impact: Admin cannot provision pilots or Sales users through the application.

#### VAL-01 — Invalid public requests are persisted

Evidence:

- A phone number containing only `x` returned HTTP 201.
- Acreage `-5` returned HTTP 201.

Impact: invalid contact and job-size data enters scheduling, messaging, billing, and CRM flows.

Required correction: validate and normalize phone numbers and require finite positive acreage on both client and server. Add upper limits and consistent field errors.

### Medium

#### AUTH-UI-01 — Login page discloses development credentials

Evidence: the page visibly contains a demo-login list and a plaintext demo password at `frontend/src/pages/Login.jsx:81-82`.

Impact: unacceptable for a hosted or customer-facing environment; it also conflicts with customer-neutral presentation.

#### ADMIN-02 — Admin fleet counts use obsolete JSON-era status names

Evidence: the backend had 10 `AVAILABLE`/`ASSIGNED` drones while the UI showed `Active & Dispatched (0)`.

Root cause: `frontend/src/pages/AdminDashboard.jsx:135-136` looks for `Active`, `Dispatched`, `Standby`, and `Maintenance`, but Prisma uses uppercase enums such as `AVAILABLE`, `ASSIGNED`, and `MAINTENANCE`.

Impact: Admin receives a materially false fleet overview.

#### A11Y-01 — Public inputs are not programmatically associated with their labels

Evidence: farmer name, phone, location, crop, and acreage inputs all had visible `<label>` text but no `for`/`id`, enclosing label, `aria-label`, or `aria-labelledby` association.

Affected code: `frontend/src/pages/LandingPage.jsx:80-83`.

Impact: screen-reader and voice-control users cannot reliably identify controls; label clicks do not focus the input.

## Additional defects/risks observed during passing workflows

1. **Pilot GPS transition race:** the successful Pilot lifecycle emitted two HTTP 409 location responses around optimistic accept/start/complete transitions. The mission still completed, but GPS effects can send against a server state that has not caught up or has just completed. Coordinate dispatch should be cancelled/serialized around state transitions.
2. **Sales background errors:** Sales workflows that otherwise pass continually receive 403 responses because the dashboard polls an Admin/Fleet-only assignment endpoint. This wastes requests and prevents complaint/reschedule information from loading.
3. **Backend test isolation is fragile:** `phase1-data-layer.test.js` assumes untouched seed state, so running it after the browser workflow fails even when the data layer is correct. Each test should own its fixtures or reseed explicitly.
4. **Backend suite can leave Phase 7 open:** under Node 24.18.0, clean reruns intermittently leave `phase7-whatsapp.test.js` alive after its assertions. The HTTP server/Undici connections need deterministic teardown, such as closing idle/all connections before awaiting `server.close`.
5. **Appeal operations UI gap:** public appeal creation works and backend review routes exist, but the inspected Sales dashboard has no clear appeal-review queue/control. This blocks an out-of-range appeal from being completed through the browser.
6. **Admin configuration gaps remain intentional production blockers:** complete pilot/drone/centre/configuration management is not present, as already recorded in `production hardening.md`.

## Placeholder outcomes — not counted as bugs

- WhatsApp messages remain mock/audited deliveries.
- UPI falls back visibly to manual cash collection.
- Weather remains fail-open with a Fleet warning when no provider is configured.
- Google Form/Apps Script is not connected to a real form.
- Five-language wording still needs native-speaker/business review.

These behaviors are deliberate until provider accounts and company decisions are supplied.

## Coverage limits

This audit is rigorous against the implemented browser workflows, but it cannot prove that no undiscovered bug exists. The following still require separate acceptance work:

- Physical Android devices, real GPS hardware, permission denial/revocation, backgrounding, and full browser termination.
- Calendar drag gesture/reschedule across browser engines; manual scheduling and backend reschedule logic are covered, but the pointer gesture was not automated here.
- Real provider sandboxes for Google, WhatsApp, weather, SMS/email, and UPI.
- Load, concurrency, penetration, dependency, secret, accessibility-standard, and backup/restore testing.
- Current desktop Firefox/Chrome/Edge and supported Android browser matrix; this run used Edge only.

## Recommended repair order

1. **P0:** protect all user/drone routes and remove `passwordHash` from every response.
2. **P0:** hash passwords and remove visible demo credentials before any network-accessible demo.
3. **P1:** repair Sales `NEW` lead rendering and remove the unauthorized assignment polling dependency.
4. **P1:** add server-side phone/acreage validation.
5. **P1:** repair Admin user creation and fleet status mapping.
6. **P2:** associate labels, resolve the GPS transition race, add the appeal-review UI, and make backend test teardown deterministic.
7. Rerun `npm run test:browser`, backend tests from a clean isolated database, Prisma validation, frontend lint, and frontend build. Release only when all required checks pass or an accountable owner explicitly accepts a documented limitation.

## Evidence

- Machine-readable results: `docs/test-evidence/browser-audit-2026-07-14/results.json`
- Per-check screenshots: `docs/test-evidence/browser-audit-2026-07-14/*.png`
- Repeatable browser harness: `frontend/e2e/browser-audit.mjs`
