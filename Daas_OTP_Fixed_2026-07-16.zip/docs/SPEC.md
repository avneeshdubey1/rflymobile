# RFLY DaaS — Master Technical Specification (v2)
**Status:** Approved for implementation
**Supersedes:** v1 (initial refactor spec, pre-automation discussion)
**Companion docs:** `AGENTS.md` (how coding agents should work in this repo), `CONTEXT.md` (business/domain background)

---

## 0. What Changed Since v1

v1 covered the role restructuring, Postgres/Prisma migration, calendar UI, and chat. Since then the scope grew in one fundamental way: **this is no longer a system where staff manually create every record — it's an automation pipeline with human fallbacks at every failure point.** Concretely, this version adds:

- Multi-channel lead intake (Website, Google Form webhook, manual entry) converging into one pipeline
- Multi-center geofencing with a negotiable out-of-range appeal flow
- An auto-assignment engine (pilot + drone matching) replacing manual fleet-manager picking, with the calendar demoted to an override tool
- An escalating pilot-notification cascade (push → SMS → dispatch call task → auto-reassign)
- A weather-suitability gate before scheduling
- DGCA compliance placeholder fields (real thresholds intentionally not hardcoded — see §9)
- WhatsApp Business API as the primary farmer-facing channel
- Payment collection (UPI + cash) with an explicit manual fallback if automation isn't live
- An immutable audit log feeding a "Logbook/CRM" job-lifecycle timeline view
- Offline-first pilot app behavior + live GPS tracking
- A proper i18n framework (Tamil first, explicitly built to extend to more languages, not hardcoded to one)
- Basic observability (health checks, structured logging)

Everything from v1 not mentioned above (Postgres/Prisma, Tailwind, react-big-calendar, Socket.io chat, role restructuring) still holds.

---

## 1. Confirmed Tech Stack

| Layer | Choice | Notes |
|---|---|---|
| Frontend framework | React (Vite) | Kept as an SPA — internal, auth-gated tool, no SEO need. Revisit only if the public landing page needs SEO later. |
| Frontend styling | Tailwind CSS | Replaces vanilla CSS |
| Animation | Framer Motion | Dashboard/calendar/chat transitions |
| Calendar | react-big-calendar (MIT) | Now an override/reschedule tool, not primary assignment method |
| Backend | Node.js + Express | Unchanged |
| Database | PostgreSQL + Prisma | Repository Pattern isolates all DB access |
| Real-time (chat + GPS) | Socket.io | Chat rooms + a live-location broadcast channel |
| Farmer messaging | WhatsApp Business API | Primary farmer-facing notification channel |
| Pilot messaging | Push (in-app) + SMS + dispatch-call task | Escalating cascade, see §6 |
| Weather data | Pluggable weather API (OpenWeatherMap or IMD) | Gate on scheduling, not a hard dependency — see §7 |
| Pilot app connectivity | Offline-first PWA | Service worker + local action queue, syncs on reconnect |
| Payments | UPI (Razorpay/similar) + Cash | UPI generates a link/QR; cash is a manual-mark flow; both feed the same `PaymentRecord` |
| i18n | File-based language dictionaries | `en.json`, `ta.json` to start; structurally ready for more |

### 1.1 Local Development (unchanged from v1)
```bash
docker run --name rfly-postgres -e POSTGRES_PASSWORD=devpass -e POSTGRES_DB=rfly_daas -p 5432:5432 -d postgres:16
```
Backend/frontend run natively (`npm run dev`) against this container. This stays compatible with a future `docker-compose.yml` — only `DATABASE_URL`'s host changes when that day comes.

---

## 2. Database Schema (Prisma)

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum Role {
  ADMIN
  SALES
  FLEET_MANAGER
  PILOT
}

enum LeadStatus {
  NEW                     // raw submission, not yet geofence-checked
  OUT_OF_RANGE            // failed geofence check
  APPEAL_PENDING          // farmer requested to pay extra / be reconsidered
  PROCESSED               // verified, inside range, ready for auto-assignment
  NEEDS_MANUAL_SCHEDULING // auto-assignment found no valid candidates
  SCHEDULED               // pilot+drone assigned, awaiting pilot acceptance
  PILOT_ACCEPTED
  IN_PROGRESS
  COMPLETED
  FLAGGED                 // discrepancy, decommission, or admin flag
  CANCELLED
  REJECTED                // appeal denied, or lead otherwise rejected
}

enum DroneStatus {
  AVAILABLE
  ASSIGNED
  MAINTENANCE
  OUT_OF_SERVICE
}

enum IntakeChannel {
  WEBSITE
  GOOGLE_FORM
  MANUAL_SALES
}

enum NotificationType {
  RESCHEDULE
  DRONE_DECOMMISSIONED
  MISSION_FLAGGED
  MISSION_COMPLETED
  LEAD_PROCESSED
  OUT_OF_RANGE_APPEAL
  NEEDS_MANUAL_SCHEDULING
  WEATHER_RISK
  PAYMENT_PENDING
}

enum PaymentMethod {
  UPI
  CASH
}

enum PaymentStatus {
  PENDING
  COMPLETED
  FAILED
}

model OperatingCenter {
  id        String   @id @default(uuid())
  name      String                          // "Tenkasi HQ", "Kanyakumari Branch"
  latitude  Float
  longitude Float
  radiusKm  Float    @default(50)
  active    Boolean  @default(true)
  createdAt DateTime @default(now())

  drones    Drone[]
  pilots    User[]
}

model User {
  id                   String    @id @default(uuid())
  name                 String
  email                String    @unique
  phone                String?
  passwordHash         String
  role                 Role
  preferredLanguage    String    @default("ta")   // ISO-ish code, see §10
  createdAt            DateTime  @default(now())

  // Pilot-specific
  homeCenter           OperatingCenter? @relation(fields: [homeCenterId], references: [id])
  homeCenterId         String?
  pilotLicenseExpiry   DateTime?        // DGCA placeholder, see §9
  assignments          Assignment[]     @relation("PilotAssignments")
  chatSessionsAsPilot  ChatSession[]    @relation("PilotChats")
  chatSessionsAsAdmin  ChatSession[]    @relation("AdminChats")
  notifications        Notification[]
}

model Drone {
  id                  String       @id @default(uuid())
  model               String
  serialNumber        String       @unique
  status              DroneStatus  @default(AVAILABLE)
  homeCenter          OperatingCenter @relation(fields: [homeCenterId], references: [id])
  homeCenterId        String
  airworthinessExpiry DateTime?    // DGCA placeholder, see §9
  lastMaintained       DateTime?
  createdAt           DateTime     @default(now())

  assignments         Assignment[]
}

model Lead {
  id               String        @id @default(uuid())
  farmerName       String
  farmerPhone      String
  farmerAddress    String?
  latitude         Float?
  longitude        Float?
  acreage          Float
  cropType         String?
  notes            String?
  preferredLanguage String       @default("ta")
  status           LeadStatus    @default(NEW)
  intakeChannel    IntakeChannel
  formResponseId   String?       @unique   // idempotency key for Google Form webhook
  surveyorName     String?                 // set when channel = GOOGLE_FORM
  matchedCenter    OperatingCenter? @relation(fields: [matchedCenterId], references: [id])
  matchedCenterId  String?
  distanceFromCenterKm Float?
  createdAt        DateTime      @default(now())
  processedAt      DateTime?

  assignment       Assignment?
  appeal           OutOfRangeAppeal?
  notifications    Notification[]
  payments         PaymentRecord[]
}

model OutOfRangeAppeal {
  id            String   @id @default(uuid())
  lead          Lead     @relation(fields: [leadId], references: [id])
  leadId        String   @unique
  distanceKm    Float
  excessKm      Float
  farmerMessage String?
  suggestedFee  Float?               // auto-calculated: excessKm * PricingConfig rate
  finalFee      Float?               // admin/sales-overridable, since customers negotiate
  status        String   @default("PENDING")  // PENDING, APPROVED, REJECTED
  reviewedBy    String?
  createdAt     DateTime @default(now())
  resolvedAt    DateTime?
}

model PricingConfig {
  id        String   @id @default(uuid())
  key       String   @unique   // e.g. "OUT_OF_RANGE_RATE_PER_KM", "DISCREPANCY_THRESHOLD_PCT"
  value     Float               // placeholder values — see §9 and §11
  updatedBy String?
  updatedAt DateTime @updatedAt
}

model Assignment {
  id                String    @id @default(uuid())
  lead              Lead      @relation(fields: [leadId], references: [id])
  leadId            String    @unique
  pilot             User      @relation("PilotAssignments", fields: [pilotId], references: [id])
  pilotId           String
  drone             Drone     @relation(fields: [droneId], references: [id])
  droneId           String

  scheduledDate     DateTime
  autoAssigned      Boolean   @default(true)   // false if a Fleet Manager manually created/overrode it
  acceptedAt        DateTime?
  startedAt         DateTime?
  completedAt       DateTime?

  weatherCheckedAt  DateTime?
  weatherSuitable   Boolean?
  weatherNote       String?

  expectedAcreage   Float
  actualAcreage     Float?
  cost              Float?
  hasDiscrepancy    Boolean   @default(false)
  discrepancyNote   String?

  decommissionedMidMission Boolean @default(false)
  decommissionReason       String?

  lastKnownLat      Float?          // live GPS, most recent ping only
  lastKnownLng      Float?
  lastPingAt        DateTime?

  rescheduleHistory ScheduleChangeLog[]
  payments          PaymentRecord[]
  createdAt         DateTime  @default(now())
}

model ScheduleChangeLog {
  id           String     @id @default(uuid())
  assignment   Assignment @relation(fields: [assignmentId], references: [id])
  assignmentId String
  oldDate      DateTime
  newDate      DateTime
  changedBy    String
  reason       String?
  createdAt    DateTime   @default(now())
}

model ChatSession {
  id                  String    @id @default(uuid())
  admin               User      @relation("AdminChats", fields: [adminId], references: [id])
  adminId             String
  pilot                User      @relation("PilotChats", fields: [pilotId], references: [id])
  pilotId             String
  status              String    @default("OPEN")
  firstResponseReadAt DateTime?
  lastActivityAt      DateTime  @default(now())
  closedAt            DateTime?
  createdAt           DateTime  @default(now())

  messages            ChatMessage[]
}

model ChatMessage {
  id          String      @id @default(uuid())
  session     ChatSession @relation(fields: [sessionId], references: [id])
  sessionId   String
  senderId    String
  content     String
  sentAt      DateTime    @default(now())
  readAt      DateTime?
}

model Notification {
  id          String            @id @default(uuid())
  type        NotificationType
  recipient   User              @relation(fields: [recipientId], references: [id])
  recipientId String
  lead        Lead?             @relation(fields: [leadId], references: [id])
  leadId      String?
  message     String
  readAt      DateTime?
  createdAt   DateTime          @default(now())
}

model PaymentRecord {
  id            String        @id @default(uuid())
  lead          Lead          @relation(fields: [leadId], references: [id])
  leadId        String
  assignment    Assignment    @relation(fields: [assignmentId], references: [id])
  assignmentId  String
  amount        Float
  method        PaymentMethod
  status        PaymentStatus @default(PENDING)
  upiLink       String?
  upiTransactionId String?
  markedCashBy  String?               // userId if manually marked collected
  createdAt     DateTime      @default(now())
  resolvedAt    DateTime?
}

// Append-only. Never updated or deleted — this is the source for the
// Logbook/CRM job-lifecycle timeline view (see §12).
model AuditLog {
  id         String   @id @default(uuid())
  entityType String              // "Lead" | "Assignment" | "Drone" | ...
  entityId   String
  action     String              // "STATUS_CHANGE" | "ADMIN_OVERRIDE" | "RESCHEDULE" | ...
  actorId    String?             // null for system/automated actions
  beforeState Json?
  afterState  Json?
  reason      String?
  createdAt   DateTime @default(now())

  @@index([entityType, entityId])
}
```

**Acceptance criteria:**
- `npx prisma migrate dev --name init` runs cleanly.
- Seed script creates: 2 `OperatingCenter`s, 1 admin, 2 sales, 2 fleet managers, 3 pilots (assigned across centers), 5 drones (across centers), 5 leads spanning several statuses including one `OUT_OF_RANGE`, `PricingConfig` rows with placeholder values (§11).

---

## 3. Backend Architecture

```
backend/
  prisma/
    schema.prisma
    seed.js
  src/
    repositories/         # ALL Prisma calls live here — controllers never import PrismaClient
      leadRepository.js
      assignmentRepository.js
      droneRepository.js
      userRepository.js
      chatRepository.js
      notificationRepository.js
      paymentRepository.js
      auditLogRepository.js
      operatingCenterRepository.js
    controllers/           # Thin — call repositories/services only
    routes/
    services/
      geofenceService.js          # Haversine check against active OperatingCenters
      autoAssignmentService.js    # Scoring, candidate filtering, DGCA/weather gates
      notificationCascadeService.js  # push -> SMS -> call-task -> reassign timers
      weatherService.js           # wraps the weather API, pure function: date+coords -> suitable bool
      whatsappService.js          # farmer-facing message templates + send
      paymentService.js           # UPI link generation + cash marking + webhook handling
      schedulingService.js        # manual override path used by Fleet Manager calendar
      chatLifecycleService.js
      auditLogService.js          # single write-path used by all other services
      i18nService.js              # resolves message templates by language code
    sockets/
      chatSocket.js
      locationSocket.js           # live GPS broadcast to Fleet Manager/Admin dashboards
    jobs/                          # scheduled/cron-style background tasks
      chatAutoClose.js
      notificationEscalation.js
      pilotAcceptanceTimeout.js
    integrations/
      googleFormWebhook.js
      whatsappClient.js
      upiClient.js
      weatherClient.js
    middleware/
      auth.js
      roleGuard.js
    app.js
```

**Hard rule (unchanged from v1, still the backbone of the whole architecture):** controllers never touch Prisma directly. Everything goes through `repositories/`. Every state-changing action funnels through `auditLogService`, since that's now the data source for the Logbook/CRM view, not just an override trail.

---

## 4. Lead / Mission State Machine

```
NEW ──(geofence check)──> PROCESSED  [inside range]
                        └─> OUT_OF_RANGE ──(farmer appeals)──> APPEAL_PENDING
                                                                   ├─(approved)→ PROCESSED
                                                                   └─(rejected)→ REJECTED

PROCESSED ──(auto-assignment engine)──> SCHEDULED  [candidates found + weather ok]
                                     └─> NEEDS_MANUAL_SCHEDULING  [no candidates, or all-week weather-blocked]
                                                                       └─(fleet manager manually schedules)→ SCHEDULED

SCHEDULED ──(pilot accepts)──> PILOT_ACCEPTED ──(pilot starts)──> IN_PROGRESS ──(pilot submits acreage)──> COMPLETED

Any state from SCHEDULED onward can branch to:
  FLAGGED     (discrepancy, mid-mission decommission, or admin flag)
  CANCELLED   (admin/sales cancels)

SCHEDULED / PILOT_ACCEPTED loop back to SCHEDULED via:
  RESCHEDULE  (fleet manager override, or auto-reassignment after cascade timeout)
```

**Server-enforced rules (unchanged core + additions):**
- Manual sales entry (in-person visit) skips straight to `PROCESSED` — a human already verified it on-site.
- Google Form and Website submissions enter at `NEW` and are geofence-checked immediately on creation.
- A lead cannot reach `IN_PROGRESS` without passing through `PILOT_ACCEPTED`.
- Only the assigned pilot can transition their own `Assignment` to `IN_PROGRESS`/`COMPLETED`.
- Only Fleet Managers (or the auto-assignment engine acting as system) can create/modify `Assignment` records.
- A `Drone` cannot be double-booked while `status = ASSIGNED`.
- A pilot or drone with an expired DGCA placeholder field (§9) is excluded from auto-assignment candidacy, but this exclusion is a **soft block surfaced to the Fleet Manager**, not a silent failure — see §9 for the fallback plan.
- Mid-mission decommission: sets `decommissionedMidMission=true`, `Drone.status=MAINTENANCE`, `Lead.status=FLAGGED`, writes `AuditLog`, notifies Fleet Manager.

---

## 5. Automation Pipeline — Intake → Geofence → Appeal

### 5.1 Three intake channels, one pipeline
| Channel | Who | Entry status | Notes |
|---|---|---|---|
| Website | Farmer (rare) or anyone with a live browser | `NEW` | Only channel with a live human at the screen — gets real-time geofence rejection + appeal UI |
| Google Form | External hired surveyor, visits field in person | `NEW` | Webhook-driven, not polled — fires the instant the surveyor submits |
| Manual entry | Sales rep, visits + has already verified in person | `PROCESSED` directly | Skips `NEW` since verification already happened physically |

Surveyors do **not** get an app login — they only ever interact with the Google Form. If that assumption is wrong, flag it; it changes the auth model.

### 5.2 Google Form webhook
Apps Script bound to the Form's response sheet, firing on submit:
```js
function onFormSubmit(e) {
  const r = e.namedValues;
  UrlFetchApp.fetch('https://yourbackend.com/api/leads/ingest/google-form', {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({
      farmerName: r['Farmer Name'][0],
      farmerPhone: r['Phone Number'][0],
      mapsLink: r['Location Pin (Google Maps link)'][0],
      acreage: r['Acreage'][0],
      cropType: r['Crop Type'][0],
      surveyorName: r['Surveyor Name'][0],
      formResponseId: e.response.getId(),   // idempotency
      secret: process.env.FORM_WEBHOOK_SECRET
    })
  });
}
```
Backend verifies the shared secret, dedupes on `formResponseId`, parses lat/long from the Maps share-link (free-text address geocoding is a fallback only — pins are the primary source since rural addresses are often too vague to geocode).

### 5.3 Geofence check
Runs immediately on `Lead` creation, against all `active` `OperatingCenter`s, using the standard Haversine distance formula. First center within whose `radiusKm` the lead falls wins (`matchedCenterId`); if none, `status = OUT_OF_RANGE`.

### 5.4 Appeal flow — channel-dependent, deliberately
The two intake paths have fundamentally different appeal UX because only one has a live human at a screen:
- **Website:** instant rejection screen — "You're 12km outside our 50km service radius" — with a button: "I'll cover the extra transport cost." Creates `OutOfRangeAppeal` with `suggestedFee` auto-calculated (§11), notifies Sales/Admin, farmer sees "pending review."
- **Google Form / Manual:** no live screen to negotiate through. Lead lands in the dashboard tagged `OUT_OF_RANGE`; Sales calls the farmer back and records the appeal outcome manually. This isn't a lesser path — a phone call closes rural sales conversations better than a form ever will.

---

## 6. Auto-Assignment Engine + Notification Cascade

### 6.1 Assignment algorithm
```
on Lead entering PROCESSED:
  center = lead.matchedCenter          # already known from geofence check

  weatherWindow = nextNSuitableDays(center.coords, N=5)   # see §7
  if weatherWindow.empty:
      status → NEEDS_MANUAL_SCHEDULING, tag WEATHER_RISK, notify Fleet Manager
      return

  candidatePilots = pilots WHERE homeCenter = center
                          AND no conflicting Assignment on target date
                          AND pilotLicenseExpiry > today (or null — see §9 fallback)
  candidateDrones = drones WHERE homeCenter = center
                          AND status = AVAILABLE
                          AND airworthinessExpiry > today (or null — see §9 fallback)

  if candidatePilots.empty OR candidateDrones.empty:
      status → NEEDS_MANUAL_SCHEDULING, notify Fleet Manager
      return

  # Drone size/capacity NOT factored in — drones are treated as interchangeable (explicit decision)
  best = highest-scoring (pilot, drone) pair by: distance to farmer + pilot's current week workload

  create Assignment(pilot=best.pilot, drone=best.drone, scheduledDate=weatherWindow.first, autoAssigned=true)
  Lead.status → SCHEDULED
  writeAuditLog(...)
  sendWhatsApp(farmer, "mission_scheduled" template)
  begin notification cascade (§6.2)
```

### 6.2 Pilot notification cascade
Redundant, but escalating rather than simultaneous — each step only fires if the prior one didn't get a response:
```
T+0     push notification to pilot (in-app)
T+15m   if not opened: SMS to pilot
T+45m   if still not accepted: create a dispatch task — "Call [Pilot] re: job #1234, auto-notify failed"
                                (a human at HQ places this call; not a robo-call)
T+2h    if still not accepted: reassign — rerun candidate scoring excluding this pilot, repeat cascade
        if no other candidate exists at this point → NEEDS_MANUAL_SCHEDULING, notify Fleet Manager
```
Implemented as a `jobs/notificationEscalationJob` polling `SCHEDULED` assignments with `acceptedAt IS NULL`, checked every 5 minutes. Timings should be env-configurable for testing (shorten to seconds/minutes in dev).

### 6.3 Manual override path (Fleet Manager calendar)
The calendar (react-big-calendar) is no longer how assignments are normally *created* — it's the override tool for `NEEDS_MANUAL_SCHEDULING` leads and for adjusting existing `SCHEDULED`/`PILOT_ACCEPTED` assignments. Drag-and-drop still works exactly as in v1 (§7.2 of v1), just narrower in scope: dragging a lead card creates an `Assignment` with `autoAssigned=false`; dragging an existing assignment reschedules it, writes `ScheduleChangeLog`, and notifies Sales.

---

## 7. Weather-Suitability Gate

A pure-function service, not a hard external dependency the whole pipeline collapses without:
```js
// services/weatherService.js
async function isSuitableForSpraying(lat, lng, date) {
  const forecast = await weatherClient.getForecast(lat, lng, date);
  return forecast.windSpeedKph < WIND_THRESHOLD
      && forecast.precipitationProbability < RAIN_THRESHOLD;
}
```
Thresholds live in `PricingConfig`-style config rows (or a sibling `OperationalConfig` table), not hardcoded — agronomic thresholds are a domain-expert call, same reasoning as the DGCA placeholders in §9. If the weather API call fails or times out, **fail open with a warning**, not closed: log it, flag the assignment `weatherSuitable = null`, notify the Fleet Manager to eyeball it manually, and proceed with scheduling. A missing weather API should degrade the system to "v1 behavior," never block the whole pipeline.

---

## 8. WhatsApp Farmer Communications

WhatsApp Business API, not SMS, for all farmer-facing messages — this is the channel farmers in this market are actually already on. Message templates, localized per `Lead.preferredLanguage` (§10):

| Trigger | Template |
|---|---|
| Lead processed | "Your request has been received and is being scheduled." |
| Mission scheduled | "A pilot has been scheduled for [date]." |
| Pilot en route / mission started | "Your pilot is on the way / has begun spraying." |
| Mission completed | "Spraying complete. [X] acres covered. Invoice: [link]." |
| Out-of-range appeal outcome | Approved/rejected + fee if applicable |

`whatsappService.js` wraps the WhatsApp Business API client; each call is template + variables + phone number + language code, so template content is swappable without touching call sites.

---

## 9. DGCA Compliance — Placeholder Fields, Explicit Fallback Plan

**Design stance:** the schema and gating logic are real and enforced now. The actual regulatory *values* (license validity periods, what counts as "expired," whether a grace period applies) are not dev-department decisions — they're placeholders until compliance/ops supplies real numbers.

- `User.pilotLicenseExpiry` and `Drone.airworthinessExpiry` are real, nullable `DateTime` fields, seeded with placeholder dates in dev.
- Auto-assignment excludes expired pilots/drones **only if the field is populated and in the past**. A `null` value does not block assignment — it just means "not yet tracked," so partial data doesn't stall the whole engine.
- The Fleet Manager dashboard surfaces a non-blocking warning banner for anything expiring within 14 days (placeholder window), and a hard exclusion (with visible reason) for anything already expired.
- **This is a soft gate, not a legal compliance system.** It's there to reduce operational risk, not to serve as the company's actual regulatory record-keeping — that distinction should stay explicit in code comments and UI copy so nobody mistakes "the app didn't flag it" for "this is DGCA-compliant."

---

## 10. Internationalization (i18n)

Explicitly designed to grow beyond Tamil, not hardcoded to one language — Tamil is the *starting* language, not the only one.

```
frontend/src/locales/
  en.json
  ta.json
  # future: te.json, kn.json, hi.json, ...
backend/src/locales/
  en.json      # WhatsApp/SMS templates, notification text
  ta.json
```
- `User.preferredLanguage` and `Lead.preferredLanguage` store an ISO-ish code (`en`, `ta`, ...).
- Frontend uses a standard key-based i18n library (e.g. `react-i18next`) — no hardcoded UI strings in components.
- Backend template resolution goes through `i18nService.resolve(templateKey, languageCode, variables)`; adding a language is a new JSON file, not a code change.
- Farmer-facing surfaces (WhatsApp, landing page) are Tamil-first; staff-facing dashboards can stay English-first initially since staff are literate in it, but should not hardcode strings either — same i18n path, just English populated first.

---

## 11. Pricing & Threshold Placeholders

Nothing rate-related is hardcoded in application code — everything lives in `PricingConfig`, editable by Admin without a deploy, because these are business decisions (marketing/ops), not dev ones:

| Key | Placeholder value | Real value owner |
|---|---|---|
| `OUT_OF_RANGE_RATE_PER_KM` | ₹15/km (placeholder) | Marketing/ops, per your note that customers negotiate |
| `DISCREPANCY_THRESHOLD_PCT` | 5% | Ops |
| `WIND_THRESHOLD_KPH` | placeholder, e.g. 15 | Agronomy/ops |
| `RAIN_PROBABILITY_THRESHOLD_PCT` | placeholder, e.g. 40 | Agronomy/ops |
| `PILOT_LICENSE_GRACE_DAYS` | placeholder, e.g. 14 | Compliance |

`OutOfRangeAppeal.suggestedFee` auto-populates from the rate above but `finalFee` is always separately editable — auto-calculation is a starting offer, not a locked price, since you've noted customers negotiate.

---

## 12. Audit Log & Logbook/CRM Timeline View

Every meaningful event on a Lead already needs logging for accountability (admin overrides, discrepancies, appeals). The "Logbook/CRM" idea your dev lead raised is the same data, presented differently: a searchable table of leads where **double-clicking a row opens a drawer showing that lead's full history as a chronological timeline** — created → geofence result → processed → auto-assigned/manually scheduled → notification cascade steps → accepted → started → GPS pings (optional, summarized) → completed/flagged → payment → appeal outcome, each entry pulled straight from `AuditLog` (and `Notification` for the messaging side).

This is not a separate system to build — it's a UI view over `AuditLog`, plus a `GET /api/audit-log?entityId=` endpoint. Because `AuditLog` is append-only and every service writes to it via the single `auditLogService`, the timeline view is complete by construction rather than something that needs its own tracking logic bolted on.

---

## 13. Payments — UPI + Cash, With an Explicit Fallback Plan

**Primary flow:** on mission `COMPLETED`, `paymentService` generates a UPI payment link + QR (via a gateway like Razorpay), creates a `PaymentRecord(status=PENDING)`, and sends it to the farmer over WhatsApp. A webhook (`POST /api/payments/:id/webhook`) marks it `COMPLETED` on confirmation.

**Cash flow:** same `PaymentRecord`, `method=CASH`. Sales/Admin manually marks it collected (`markedCashBy`) after the pilot or a rep confirms cash was received in person — this is expected to be common, not an edge case, given the customer base.

**Evasion / fallback plan — what happens if payment automation isn't implemented yet, or the gateway integration isn't live:** mission completion **never blocks on payment**. `Assignment.status` reaches `COMPLETED` regardless of payment state. A `PaymentRecord(status=PENDING)` is still created with the computed `cost` even if no UPI link was generated — it simply sits in a **"Pending Manual Collection"** list on the Sales/Admin dashboard, sorted oldest-first, with the farmer's contact info surfaced for a follow-up call. This means: if the UPI integration is delayed, cut, or fails mid-build, the business doesn't lose track of who owes what — it just reverts to the same manual-follow-up process that exists today, with the system doing the bookkeeping instead of a spreadsheet.

---

## 14. Offline-First Pilot App + Live GPS Tracking

**Why this matters (competitive gap, not a nice-to-have):** rural connectivity can't be assumed. The pilot-facing surface must be a PWA with a service worker and a local action queue (IndexedDB): Accept/Start/Complete/Decommission actions are written locally first, marked `pendingSync`, and pushed to the backend as soon as connectivity returns. The UI reflects the local optimistic state immediately regardless of network status.

**Live GPS:** while `Assignment.status IN (PILOT_ACCEPTED, IN_PROGRESS)`, the pilot app pings location periodically (interval configurable, e.g. every 60s when online) to `POST /api/assignments/:id/location`, which updates `lastKnownLat/Lng/At` and broadcasts over a Socket.io `locationSocket` room to any Fleet Manager/Admin dashboard watching that assignment. If offline, pings queue locally and flush in a burst on reconnect rather than being lost. This is scoped to *current location during an active mission* — a full historical route trail is explicitly a later enhancement, not required now.

---

## 15. Observability

Lightweight, not a full stack — the goal is "know fast when the automated pipeline silently breaks," since that's now a real risk with more of the system running unattended:

- `GET /api/health` — checks DB connectivity, returns 200/503.
- Structured JSON logging (even to a file is fine for now) on every service in `services/`, especially `autoAssignmentService`, `notificationCascadeService`, and the Google Form webhook handler — these are the pieces that run without a human watching.
- The notification-escalation job and chat auto-close job should log a heartbeat each run, so a missing heartbeat is itself detectable later (e.g. via an external uptime/cron-monitor ping — flagged as a future integration, not required now).

---

## 16. Role-by-Role Feature Spec (updated from v1)

### 16.1 Admin ("God Mode")
- Master layout, override any Lead/Assignment status with a required reason (written to `AuditLog`).
- Drone Enquiry Chat (Socket.io) — unchanged from v1 (§5.1 of v1).
- Manages `OperatingCenter`s and `PricingConfig` values.
- Reviews `OutOfRangeAppeal`s alongside Sales.
- Sees the "Pending Manual Collection" payments list.

### 16.2 Fleet Manager
- Drones (CRUD, maintenance, airworthiness tracking) + pilot scheduling.
- Primary queue is now `NEEDS_MANUAL_SCHEDULING`, not "all leads" — the calendar is the exception-handling tool, not the default path.
- Sees weather-risk and DGCA-expiry warnings surfaced by the auto-assignment engine.

### 16.3 Sales Rep
- Processes `NEW` leads that came from the Google Form (verifies before `PROCESSED`); manual entries they create themselves already start at `PROCESSED`.
- Handles `OUT_OF_RANGE` appeals for Form/Manual-channel leads via phone follow-up.
- "Reschedule & Notifications" tab (from v1) plus visibility into WhatsApp delivery status.
- Logbook/CRM tab — searchable lead table with the double-click timeline drawer (§12).

### 16.4 Pilot
- Sees `Assignment`s where `pilotId = self`, status `SCHEDULED`/`PILOT_ACCEPTED`/`IN_PROGRESS`.
- Dynamic drone binding (unchanged from v1) — drone auto-unbinds on `COMPLETED`.
- Accept / Start / Submit Acreage / Decommission actions, all offline-capable (§14).
- Background GPS ping while a mission is active.

---

## 17. API Endpoints (additions/changes over v1)

```
POST   /api/leads/ingest/google-form     (webhook, shared secret, idempotent on formResponseId)
POST   /api/leads                        (public website + manual sales entry)
GET    /api/leads/:id/appeal-options      (website real-time rejection screen)
POST   /api/leads/:id/appeal              (farmer submits appeal — website only)
PATCH  /api/leads/:id/appeal/review       (sales/admin — Form/manual channel outcomes)
PATCH  /api/leads/:id/process             (sales)
PATCH  /api/leads/:id/override            (admin — force-transition + reason)

POST   /api/assignments                  (fleet manager manual create)
PATCH  /api/assignments/:id/reschedule   (fleet manager)
PATCH  /api/assignments/:id/accept       (pilot)
PATCH  /api/assignments/:id/start        (pilot)
PATCH  /api/assignments/:id/complete     (pilot)
POST   /api/assignments/:id/decommission (pilot)
POST   /api/assignments/:id/location     (pilot GPS ping)
GET    /api/assignments/:id/location     (fleet manager/admin live view)

POST   /api/payments/:assignmentId/generate-link   (UPI)
POST   /api/payments/:assignmentId/webhook         (gateway confirms)
PATCH  /api/payments/:assignmentId/mark-cash        (sales/admin)
GET    /api/payments/pending                        (Pending Manual Collection list)

GET    /api/operating-centers
POST   /api/operating-centers            (admin)
PATCH  /api/pricing-config/:key          (admin)

GET    /api/audit-log?entityType=&entityId=   (Logbook/CRM timeline)
GET    /api/notifications?recipient=me
POST   /api/chat/sessions
GET    /api/chat/sessions/:id/messages
GET    /api/health
POST   /api/system/seed                  (dev only)
```

---

## 18. Build Order (Phases for Coding Agents)

**Phase 1 — Data Layer**
Postgres container, `schema.prisma` (§2), migration, seed script, all `repositories/`.
*Acceptance:* Fresh clone + migrate + seed produces a working dataset spanning every `LeadStatus`.

**Phase 2 — Automation Pipeline: Intake + Geofencing + Appeals**
Google Form webhook, website submission endpoint, `geofenceService`, `OutOfRangeAppeal` flow (both channel variants, §5.4).
*Acceptance:* A Form submission outside all `OperatingCenter` radii lands as `OUT_OF_RANGE` and appears in Sales's queue; a website submission triggers the real-time appeal UI.

**Phase 3 — Auto-Assignment Engine + Weather + DGCA Gates + Notification Cascade**
`autoAssignmentService`, `weatherService` (fail-open per §7), DGCA soft-gating (§9), `notificationCascadeService` + `jobs/notificationEscalationJob`.
*Acceptance:* A `PROCESSED` lead with valid candidates auto-schedules within one job cycle; an unaccepted assignment escalates through push→SMS→call-task→reassign on the (dev-shortened) timers; a lead with no valid candidates lands in `NEEDS_MANUAL_SCHEDULING` with a visible reason.

**Phase 4 — State Machine & Role Permissions**
Guard rails from §4, role-restricted endpoints.
*Acceptance:* Sales cannot call assignment-creation endpoints (403); pilot cannot skip `PILOT_ACCEPTED`.

**Phase 5 — Calendar Override UI**
`react-big-calendar` in Fleet Manager dashboard, scoped to `NEEDS_MANUAL_SCHEDULING` + reschedule use cases.
*Acceptance:* Dragging a `NEEDS_MANUAL_SCHEDULING` lead onto a pilot/day creates a real `Assignment`; rescheduling an existing one logs `ScheduleChangeLog` and notifies Sales.

**Phase 6 — Socket.io Chat**
Unchanged from v1 §6/Phase 4 — Admin↔Pilot chat, read receipts, 6h auto-close.

**Phase 7 — WhatsApp Farmer Communications**
`whatsappService`, templates (§8), wired to lead status transitions.
*Acceptance:* Each lifecycle trigger in §8's table sends the correct templated, language-correct message.

**Phase 8 — Payments (UPI + Cash) with Fallback**
`paymentService`, UPI link generation, webhook handler, cash-marking flow, Pending Manual Collection dashboard list (§13).
*Acceptance:* Mission completion always creates a `PaymentRecord` regardless of UPI integration status; cash-marking works end to end; nothing blocks on payment.

**Phase 9 — Offline-First Pilot PWA + Live GPS**
Service worker, local action queue, `locationSocket`, live-tracking view for Fleet Manager/Admin.
*Acceptance:* Airplane-mode test — accept/start/complete actions queue locally and sync correctly on reconnect; GPS pings resume and flush after reconnect.

**Phase 10 — Audit Log + Logbook/CRM Timeline UI**
`auditLogService` wired into every state-changing service, `GET /api/audit-log`, Sales-side searchable table + double-click timeline drawer.
*Acceptance:* Every transition performed in Phases 2–9's testing is visible, in order, in a lead's timeline drawer.

**Phase 11 — i18n Framework**
`en.json`/`ta.json` on frontend and backend, `react-i18next` wiring, `i18nService`.
*Acceptance:* Switching `preferredLanguage` changes farmer-facing WhatsApp templates and (where implemented) UI strings, with zero hardcoded strings in touched components.

**Phase 12 — Tailwind UI Overhaul**
As v1 §7/Phase 5 — full re-skin, remove `.glass-card`/`.tilt-effect`.

**Phase 13 — Observability**
`/api/health`, structured logging on unattended services, job heartbeats.

**Phase 14 — Cleanup**
Remove old `FlushPage.jsx` JSON-seeding path, repoint to `/api/system/seed`, write top-level `README.md` (local dev, architecture summary, pointer to this spec + `CONTEXT.md` + `AGENTS.md`).

---

## 19. Explicitly Out of Scope (for now)

- Full `docker-compose.yml` orchestration (deferred to post-Phase 14, noted in README).
- Third-party marketplace intake integrations are deferred business/strategy decisions and are not built.
- Historical GPS route trails (only current-location-during-active-mission is in scope now).
- Robo-call automation for the notification cascade — the "call" escalation step is a human dispatch task, not an automated voice call.
- Horizontal scaling of Socket.io (Redis adapter) — only needed once running multiple backend instances.
- Payment gateway selection specifics (which UPI provider) — placeholder integration point, not a locked vendor choice.
- Mobile app store packaging (the offline-first pilot experience is a PWA, not a native app, for now).

---

## 20. Open Items Requiring Non-Dev Input Before Relevant Phases Start

- Real values for every row in §11's placeholder table (rates, thresholds) — marketing/ops/agronomy/compliance owners, not dev.
- Real DGCA license/airworthiness validity rules (§9) — compliance owner.
- Whether external surveyors ever need any form of authenticated access (currently assumed: no, Google Form only — confirm before Phase 2).
- UPI payment gateway vendor selection (Phase 8 blocked without this, though the fallback path means Phase 8 can still ship without it).
- Full language rollout list beyond Tamil/English (Phase 11 ships with 2 languages regardless; more are just additional JSON files whenever ops decides).
