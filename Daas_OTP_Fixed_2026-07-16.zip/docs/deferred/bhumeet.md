# Deferred External Marketplace Integration

This document is the only current holding place for the removed Bhumeet-specific work. It is deliberately outside the active application plan and must not be mounted, bundled, called, or treated as a product dependency unless the user explicitly reopens this topic.

## Removed on July 13, 2026

- Admin dashboard tab, UI/JSON mock feed, and client requests.
- Express route and controller, including the unused external-login helper.
- Root connectivity test, which was unsafe because it contained a plaintext credential.
- Bhumeet as the Admin dashboard's default view; Fleet Overview is now the default.

No source code or credential was archived here. Historical change entries remain in `history_of_changes.md` because that file records what previously happened, not what is currently enabled.

## If the topic is reopened later

Treat it as a new integration. Obtain explicit business approval, a supported API contract, a sandbox account, data-ownership and privacy terms, webhook/authentication requirements, rate limits, and an agreed mapping into this product's tenant model. Store credentials only in a deployment secret manager and add negative authorization, timeout, retry, idempotency, audit-redaction, and failure-fallback tests before enabling it.
