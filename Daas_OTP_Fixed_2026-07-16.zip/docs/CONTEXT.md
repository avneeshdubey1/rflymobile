# CONTEXT.md — Business & Domain Background

This file explains the *why* behind `SPEC.md`. A coding agent that only reads the spec can implement the letter of it correctly and still make bad judgment calls on ambiguous edge cases without this context.

---

## 1. Who This Is For

RFLY (rfly.net) is an agricultural drone service company operating in Tamil Nadu, India. They own their own drone fleet and employ hired pilots — this is a **single-operator DaaS (Drone as a Service) business**, not a marketplace. Farmers request spraying services; RFLY dispatches one of its own pilots with one of its own drones.

This codebase is being built by an external consultancy on RFLY's behalf. The person you're likely getting instructions from in this repo is a developer at that consultancy, not RFLY's own staff — they relay RFLY's business decisions but don't always have the authority (or the domain expertise) to make agronomy, compliance, or pricing calls themselves. That's the reasoning behind the "placeholder values" pattern used throughout `SPEC.md` — those aren't laziness, they're a deliberate boundary between what dev can decide and what the client/domain experts need to decide.

---

## 2. The Business Model, Concretely

A typical job, start to finish:
1. A farmer needs their field sprayed (pesticide, nutrients, etc.).
2. Someone gets the farmer's details into the system — usually **not** the farmer typing it into a website themselves.
3. RFLY assigns a pilot and a drone to the job.
4. The pilot travels to the field, flies the mission, sprays the requested acreage.
5. The pilot reports how much was actually sprayed (which may differ from what was requested — a "discrepancy").
6. RFLY charges the farmer.

Every part of `SPEC.md` maps to making one of these six steps faster, more reliable, or less dependent on a human remembering to do something.

---

## 3. Why Intake Isn't Just "a Website Form"

This is the single most important piece of context for understanding why the intake pipeline looks the way it does.

**The realistic assumption is not that farmers are illiterate — it's that, for the most part, farmers are not the ones directly entering data into a web app.** Two things are true simultaneously and neither is a stereotype to lean on carelessly:
- Many farmers in this market are more comfortable with a phone call or an in-person conversation than a web form.
- The actual, current, real-world data collection process is: **a company representative physically visits the field.**

That representative is one of two people:
- **An externally hired surveyor** who is *not* an RFLY employee — they fill in a Google Form on-site as their deliverable back to the company. They do not get an app login; the Form is their entire interface.
- **An RFLY sales employee** who visits, has the conversation with the farmer directly (the actual described scenario: "visits the field, has some tea, enters the info manually via the app, and leaves"), and enters the lead directly into the web app.

The **website self-submission channel still exists and matters** — some farmers, or their tech-comfortable relatives/neighbors, absolutely will use it directly — but it's the minority case, not the primary design target. Design the website flow to be as good as it can be (it's the only channel with a live human at the screen, which is why it gets the real-time appeal UX), but don't assume it will carry the bulk of intake volume.

**What this means for engineering priorities:** the Google Form → webhook pipeline is not a secondary integration bolted onto a "real" website flow — it is, realistically, the primary intake channel, and should get equivalent engineering care.

---

## 4. Why Geofencing Has a Negotiation Path, Not Just a Hard Cutoff

The business has a physical service radius around each operating location — flying a drone crew 60km away costs real money in transport/time that a 50km job doesn't. But rigid radius cutoffs lose real revenue: a farmer 12km outside the line who's willing to cover the extra transport cost is a job the business would probably still take, if someone made the offer.

The appeal flow exists to capture that revenue without requiring every borderline case to become a fully manual negotiation. The fee is auto-suggested (distance-based) so the default case moves fast, but always human-overridable, because real negotiations don't always land on a formula's exact number.

**Multiple operating centers** exist because RFLY's footprint isn't a single office — it may have several physical bases (the concrete example given was Tenkasi and a South Kanyakumari location, potentially Madurai too), each acting as its own 50km-radius zone. A lead is in-range if it falls within *any* center's radius, not just the nearest one.

---

## 5. Why Auto-Assignment Exists

The manual process — sales enters a lead, fleet manager "pulls his finger muscle" (their words) and picks a pilot/drone by hand — doesn't scale. It's slow, depends on one person's availability and attention, and has no fallback if that person is busy. The auto-assignment engine (`SPEC.md` §6) exists to make the *default* path automatic, with the calendar/manual scheduling demoted to an exception-handling tool for the cases automation genuinely can't resolve (no candidates available, weather-blocked, expired compliance fields).

This is also why the notification cascade escalates rather than just firing once: a pilot who doesn't see a push notification isn't a dead end, it's an expected occurrence in the field, and the system needs to degrade gracefully through SMS, then a human phone call, then reassignment — never just silently waiting forever.

---

## 6. Regional & Language Context

Operations are currently Tamil Nadu-based (Tenkasi, Kanyakumari area, possibly Madurai). Tamil is the starting farmer-facing language, but **this is explicitly expected to grow into multiple regional languages** as operations expand — it is not a Tamil-only product decision, and the i18n architecture (`SPEC.md` §10) is built file-based specifically so adding Telugu, Kannada, Hindi, etc. later is a translation task, not an engineering one.

---

## 7. Glossary

| Term | Meaning |
|---|---|
| **DaaS** | Drone as a Service — farmers pay per job, don't own drones |
| **DSP** | Drone Service Provider — an operator that supplies drone-based services to customers |
| **Lead** | A farmer's service request, from first contact through completion — the central record of the whole system |
| **Assignment** | The pairing of a Lead with a specific Pilot + Drone + date |
| **Operating Center** | A physical base location RFLY operates from; defines a geofenced service radius |
| **Geofence** | The radius check determining whether a Lead is serviceable from an existing center |
| **Appeal** | A farmer's request to be serviced despite being outside the geofence, typically offering to cover extra cost |
| **Surveyor** | An externally hired (non-employee) person who visits farms and records details via Google Form |
| **Discrepancy** | Mismatch between requested/expected acreage and what the pilot actually sprayed |
| **Decommission (mid-mission)** | A pilot releasing/returning a drone before mission completion due to an issue |
| **Auto-assignment** | The system automatically matching a Processed lead to a pilot+drone without human selection |
| **Notification cascade** | The escalating pilot-notification sequence: push → SMS → human dispatch call → auto-reassign |
| **NEEDS_MANUAL_SCHEDULING** | The fallback Lead status when auto-assignment can't find valid candidates |
| **Logbook / CRM tab** | The searchable lead view where double-clicking opens a chronological job-history timeline |
| **God Mode** | Informal term (from the original brainstorm) for the Admin role's override-everything capability |

---

## 9. Design Principles to Carry Forward

If a new feature request comes in that isn't covered by `SPEC.md`, these principles (extracted from how the existing decisions were made) should guide judgment calls:

1. **Automate the common case, always leave a human-visible manual fallback for the rest.** Never silent failure.
2. **Business-owned values (rates, thresholds, compliance windows) are config, not code.** Dev builds the mechanism; domain experts own the numbers.
3. **Design for the channel that's actually being used, not the one that's easiest to build for.** The Google Form/surveyor pipeline matters as much as the website, arguably more.
4. **Real-world fallback behaviors (a phone call, cash payment, manual scheduling) aren't legacy cruft to eliminate — they're permanent parts of the system**, because the operating environment (rural India, variable connectivity, variable literacy/tech-comfort) makes them structurally necessary, not just a transitional crutch until "the app is finished."
