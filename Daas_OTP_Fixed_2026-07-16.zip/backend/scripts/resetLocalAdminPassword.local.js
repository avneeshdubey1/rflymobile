const path = require('node:path');
const readline = require('node:readline');
const dotenv = require('dotenv');
const userRepository = require('../src/repositories/userRepository');
const auditLogService = require('../services/auditLogService');
const { hashPassword } = require('../services/passwordService');
const prisma = require('../src/lib/prisma');

dotenv.config({ path: path.resolve(__dirname, '../.env'), quiet: true });

const DEFAULT_ADMIN_EMAIL = 'admin@fieldops.example';

function promptHidden(label) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    return Promise.reject(new Error('Run this script interactively in a local terminal.'));
  }

  return new Promise((resolve, reject) => {
    const input = process.stdin;
    const output = process.stdout;
    const wasRaw = Boolean(input.isRaw);
    let value = '';

    readline.emitKeypressEvents(input);
    input.setRawMode(true);
    input.resume();
    output.write(label);

    const finish = (callback) => {
      input.removeListener('keypress', onKeypress);
      input.setRawMode(wasRaw);
      input.pause();
      output.write('\n');
      callback();
    };

    const onKeypress = (character, key = {}) => {
      if (key.ctrl && key.name === 'c') {
        finish(() => reject(new Error('Password reset cancelled.')));
        return;
      }
      if (key.name === 'return' || key.name === 'enter') {
        finish(() => resolve(value));
        return;
      }
      if (key.name === 'backspace') {
        if (value.length > 0) {
          value = value.slice(0, -1);
          output.write('\b \b');
        }
        return;
      }
      if (!key.ctrl && !key.meta && character) {
        value += character;
        output.write('*');
      }
    };

    input.on('keypress', onKeypress);
  });
}

async function main() {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('This local development reset script cannot run in production.');
  }

  const email = String(process.env.LOCAL_ADMIN_EMAIL || DEFAULT_ADMIN_EMAIL).trim().toLowerCase();
  const admin = await userRepository.findByEmail(email);
  if (!admin || admin.role !== 'ADMIN') {
    throw new Error('No matching Admin account was found. Set LOCAL_ADMIN_EMAIL locally if this installation uses a different Admin email.');
  }

  const password = await promptHidden('New Admin password: ');
  const confirmation = await promptHidden('Confirm new Admin password: ');
  if (password !== confirmation) throw new Error('The password entries did not match. No changes were made.');

  await userRepository.updatePasswordHash(admin.id, await hashPassword(password));
  await auditLogService.record({
    entityType: 'User',
    entityId: admin.id,
    action: 'LOCAL_DEVELOPMENT_ADMIN_PASSWORD_RESET',
    actorId: admin.id,
    afterState: { resetMethod: 'local-development-script' },
  });

  console.log('Admin password reset completed. You can now sign in with the new password.');
}

main()
  .catch((error) => {
    console.error(`Admin password reset did not complete: ${error.message}`);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
